# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import order_confirm_wizard
import request_payment_term_wizard
import order_confirm_by_sales_support_wizard
import order_split_machine_change
import purchase_request
import sale_support_reserve_wizard
import mail_compose
import sale_order_lpo
