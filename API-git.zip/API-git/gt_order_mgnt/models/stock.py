from openerp import fields, models ,api, _,SUPERUSER_ID
from openerp.exceptions import UserError, ValidationError
import logging
from datetime import datetime, date, timedelta
import openerp.addons.decimal_precision as dp
import math
from openerp.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
_logger = logging.getLogger(__name__)
import json

class stock_return_picking(models.Model):
    _inherit = 'stock.return.picking'
    _description = 'Return Picking'
    reverse_reason=fields.Selection([('reject', 'Goods Rejected'), ('notdelivered', 'Not Delivered')], string="Reverse  Reason")
    
    @api.v7
    def _create_returns(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        record_id = context and context.get('active_id', False) or False
        move_obj = self.pool.get('stock.move')
        pick_obj = self.pool.get('stock.picking')
        uom_obj = self.pool.get('product.uom')
        data_obj = self.pool.get('stock.return.picking.line')
        pick = pick_obj.browse(cr, uid, record_id, context=context)
        data = self.read(cr, uid, ids[0], context=context)
        returned_lines = 0
        # Cancel assignment of existing chained assigned moves
        moves_to_unreserve = []
        for move in pick.move_lines:
            to_check_moves = [move.move_dest_id] if move.move_dest_id.id else []
            while to_check_moves:
                current_move = to_check_moves.pop()
                if current_move.state not in ('done', 'cancel') and current_move.reserved_quant_ids:
                    moves_to_unreserve.append(current_move.id)
                split_move_ids = move_obj.search(cr, uid, [('split_from', '=', current_move.id)], context=context)
                if split_move_ids:
                    to_check_moves += move_obj.browse(cr, uid, split_move_ids, context=context)

        if moves_to_unreserve:
            move_obj.do_unreserve(cr, uid, moves_to_unreserve, context=context)
            #break the link between moves in order to be able to fix them later if needed
            move_obj.write(cr, uid, moves_to_unreserve, {'move_orig_ids': False}, context=context)

        #Create new picking for returned products
        pick_type_id = pick.picking_type_id.return_picking_type_id and pick.picking_type_id.return_picking_type_id.id or pick.picking_type_id.id
        new_picking = pick_obj.copy(cr, uid, pick.id, {
            'move_lines': [],
            'picking_type_id': pick_type_id,
            'state': 'draft',
            'origin': pick.name,
            'reverse_reason':data['reverse_reason'],
            'location_id': pick.location_dest_id.id,
            'location_dest_id': data['location_id'] and data['location_id'][0] or pick.location_id.id,
        }, context=context)

        for data_get in data_obj.browse(cr, uid, data['product_return_moves'], context=context):
            move = data_get.move_id
            if not move:
                raise UserError(_("You have manually created product lines, please delete them to proceed"))
            new_qty = data_get.quantity
            if new_qty:
                # The return of a return should be linked with the original's destination move if it was not cancelled
                if move.origin_returned_move_id.move_dest_id.id and move.origin_returned_move_id.move_dest_id.state != 'cancel':
                    move_dest_id = move.origin_returned_move_id.move_dest_id.id
                else:
                    move_dest_id = False
                returned_lines += 1
                location_id = data['location_id'] and data['location_id'][0] or move.location_id.id
                move_obj.copy(cr, uid, move.id, {
                    'product_id': data_get.product_id.id,
                    'product_uom_qty': new_qty,
                    'picking_id': new_picking,
                    'state': 'draft',
                    'location_id': move.location_dest_id.id,
                    'location_dest_id': location_id,
                    'picking_type_id': pick_type_id,
                    'warehouse_id': pick.picking_type_id.warehouse_id.id,
                    'origin_returned_move_id': move.id,
                    'procure_method': 'make_to_stock',
                    'move_dest_id': move_dest_id,
                })

        if not returned_lines:
            raise UserError(_("Please specify at least one non-zero quantity."))

        pick_obj.action_confirm(cr, uid, [new_picking], context=context)
        pick_obj.action_assign(cr, uid, [new_picking], context=context)
        return new_picking, pick_type_id
        
class StockMove(models.Model):
     _inherit='stock.move'

     
     product_hs_code=fields.Char('Hs Code', related='product_id.product_hs_code')
     gross_weight=fields.Float('Gross Weight', related='product_id.weight')
     scrap_reason=fields.Selection([('reject','Quality not Good'),('min','Minimum Quantity ' )], string="Scrap Reason")
     uploaded_documents = fields.Many2many('ir.attachment','move_attachment_rel','move_doc','id','Scrap Documents')
     split_id=fields.Many2one('stock.picking.split')
     split_qty=fields.Float('Split Qty')
     rm_qty=fields.Float('Remaining Qty', compute='total_remaining_qty')  
     split_move_id=fields.Many2one('stock.move') 
     #check_quality_qty= fields.Boolean('is Qty Move',default=False) # CH_N108 add field to check qty is moved to stock from quality is or not

     @api.multi
     @api.depends('product_uom_qty', 'split_qty')
     def total_remaining_qty(self):
         for record in self:
             if record.split_qty:
                record.rm_qty=record.product_uom_qty - record.split_qty

     @api.v7
     def action_scrap(self, cr, uid, ids, quantity, location_id, restrict_lot_id=False, restrict_partner_id=False, context=None):
        """ Move the scrap/damaged product into scrap location
        @param cr: the database cursor
        @param uid: the user id
        @param ids: ids of stock move object to be scrapped
        @param quantity : specify scrap qty
        @param location_id : specify scrap location
        @param context: context arguments
        @return: Scraped lines
        """
        quant_obj = self.pool.get("stock.quant")
        move_val = self.pool.get("stock.move")
        #quantity should be given in MOVE UOM
        if quantity <= 0:
            raise UserError(_('Please provide a positive quantity to scrap.'))
        res = []
        for move in self.browse(cr, uid, ids, context=context):
            source_location = move.location_id
            scrap=move.scrap_reason
            uploaded=move.uploaded_documents
            scrap_txt = 'Minimum Quantity' if move.scrap_reason == 'min' else 'Quality not Good'
            if move.state == 'done':
                source_location = move.location_dest_id
            #Previously used to prevent scraping from virtual location but not necessary anymore
            #if source_location.usage != 'internal':
                #restrict to scrap from a virtual location because it's meaningless and it may introduce errors in stock ('creating' new products from nowhere)
                #raise UserError(_('Forbidden operation: it is not allowed to scrap products from a virtual location.'))
            move_qty = move.product_qty
            default_val = {
                'location_id': source_location.id,
                'product_uom_qty': quantity,
                'state': move.state,
                'scrapped': True,
                'location_dest_id': location_id,
                'restrict_lot_id': restrict_lot_id,
                'restrict_partner_id': restrict_partner_id,
                'scrap_reason':scrap,
                'uploaded_documents':uploaded.ids
            }
            new_move = self.copy(cr, uid, move.id, default_val)
            for mv in move_val.browse(cr, uid, new_move, context=context):
                mv.scrap_reason=scrap
                mv.uploaded_documents=uploaded.ids
                
            mrp=self.pool.get('mrp.production')
            mrp_search=mrp.search(cr, uid,[('name','=', move.origin)],context=context)
            for mp in mrp.browse(cr, uid, mrp_search, context=context):
                mp.uploaded_documents=uploaded.ids
                message = _('<h4 style="color:red"> <b>Moved to scrap.</b> <li>Product : %s </li><li>Quantity :%s %s</li> <li>Reason: %s</li></h4> <li>Documents :') % (move.product_id.name ,quantity, mp.product_uom.name,scrap_txt)
                mp.message_post(body=message, attachment_ids=move.uploaded_documents)
            
            res += [new_move]
            product_obj = self.pool.get('product.product')
            for product in product_obj.browse(cr, uid, [move.product_id.id], context=context):
                if move.picking_id:
                    uom = product.uom_id.name if product.uom_id else ''
                    attachments=move.uploaded_documents and [('move.uploaded_documents', sign.decode('base64'))] or []
                    message = _('<h4 style="color:red"> <b>Moved to scrap.</b> <li>Product : %s </li><li>Quantity :%s %s</li> <li>Reason: %s</li></h4> <li>Documents :') % (move.product_id.name ,quantity, uom,scrap_txt)
                    move.picking_id.message_post(body=message, attachments=attachments)

            # We "flag" the quant from which we want to scrap the products. To do so:
            #    - we select the quants related to the move we scrap from
            #    - we reserve the quants with the scrapped move
            # See self.action_done, et particularly how is defined the "preferred_domain" for clarification
            scrap_move = self.browse(cr, uid, new_move, context=context)
            if move.state == 'done' and scrap_move.location_id.usage not in ('supplier', 'inventory', 'production'):
                domain = [('qty', '>', 0), ('history_ids', 'in', [move.id])]
                # We use scrap_move data since a reservation makes sense for a move not already done
                quants = quant_obj.quants_get_preferred_domain(cr, uid, quantity, scrap_move, domain=domain, context=context)
                quant_obj.quants_reserve(cr, uid, quants, scrap_move, context=context)

        self.action_done(cr, uid, res, context=context)
	#code to create scrap picking
	for record in self.browse(cr, uid, ids, context=context):
	   if record.picking_id.n_code != 'incoming':
                mrp_search = self.pool.get('mrp.production').search(cr,uid,[('name','=',record.origin),('state','!=','done')])
                if mrp_search:
                   self.pool.get('stock.move').write(cr,uid,res,{'production_id':mrp_search[0],'state':'done'})
                else:
		   picking_search = self.pool.get('stock.picking').search(cr,uid,[('origin','=',record.picking_id.name),('state','!=','done')])
 		   if picking_search:
			self.pool.get('stock.move').write(cr,uid,res,{'picking_id':picking_search[0],'state':'assigned'})
		   else:
			location = self.pool.get('stock.location').search(cr,uid,[('usage','=','internal'),('active','=',True),('scrap_location','=',True)],limit=1)
			cr.execute("select id from stock_picking_type where code='internal' and n_scrap_ck=True")
			picking_type=cr.fetchone()
			name = self.pool.get('ir.sequence').next_by_code(cr,uid,'scrap.sequence') or 'New'
			picking_id=self.pool.get('stock.picking').copy(cr,uid,record.picking_id.id,
						{'origin':record.picking_id.name,'location_dest_id':record.picking_id.location_id.id,
						'picking_type_id':picking_type[0] if picking_type else False,'min_date':date.today(),'name':name,
						'location_id':location[0] if location else False,'move_lines':[]},context=context)
			self.pool.get('stock.move').write(cr,uid,res,{'picking_id':picking_id,'state':'assigned'})
        return res

class Stock_Vahicle_Number(models.Model):
     _name='stock.vahicle.number'
     name=fields.Char('Number')

class StockPickingSplit(models.Model):
     _name='stock.picking.split'

     name=fields.Char('Name')
     move_line_id=fields.One2many('stock.move', 'split_id')
     required_date=fields.Datetime('Delivery Date') 
     picking_id=fields.Many2one('stock.picking','Delivery Order')
     qty_exceed=fields.Boolean(compute='total_remaining_qty')

     @api.multi
     @api.depends('move_line_id.product_uom_qty', 'move_line_id.split_qty')
     def total_remaining_qty(self):
         for record in self:
             for line in record.move_line_id:
                 if line.split_qty:
                    if line.split_qty > line.product_uom_qty:
                       record.qty_exceed=True
                       
     @api.v7
     def create_new_delivery_order(self, cr, uid, ids, context=None):
        list_l=[]
        sh_l=[] 
        move_obj = self.pool.get('stock.move')
        picking_obj = self.pool.get('stock.picking')
	stock_quant = self.pool.get('stock.quant')
        for rec in self.browse(cr, uid, ids, context):
             res=picking_obj.copy(cr,uid, rec.picking_id.id,{'move_lines':[]},context)
	     for line in rec.move_line_id:
		 if line.product_uom_qty<line.split_qty:
			raise UserError('Split Quantity is not greater Than Quantity')
		 if (line.product_uom_qty-line.split_qty)>0:
	                 line.split_move_id.product_uom_qty =  line.product_uom_qty-line.split_qty 
		 if (line.product_uom_qty-line.split_qty)==0:
			line.split_move_id.unlink()
		 if line.split_qty >0.0:

			if line.split_move_id.reserved_quant_ids:
				quant_qty=0.0
				quant=False
				quant_list=[]
				for main_quant in line.split_move_id.reserved_quant_ids:
					quant_qty += main_quant.qty			#get reserve qty from stock quant
					quant_list.append((main_quant.id,main_quant.qty))
				if len(quant_list) == 1:	#for only one record in stock quant 
					for main_quant1 in line.split_move_id.reserved_quant_ids:
						qty=(line.product_uom_qty-line.split_qty)
						if main_quant1.qty > qty:
							quant=stock_quant.copy(cr,uid, main_quant1.id,{'reservation_id':line.id,'in_date':date.today(),'qty':(main_quant1.qty-qty)},context)	# create new records in quant
							main_quant1.write({'qty':qty})
				elif quant_qty >= line.product_uom_qty:			#compare quant qty with Parent Delivery order qty
					flag=True
					n_quant_qty=quant_qty
					for main_quant2 in line.split_move_id.reserved_quant_ids:
						if main_quant2.qty == line.split_qty and n_quant_qty==quant_qty:	#update quant with new stock move when delivery qty is same as quant qty
							main_quant2.write({'reservation_id':line.id,'in_date':date.today()})
							n_quant_qty -= main_quant2.qty
							flag=False
					if flag:
						m_quant_qty=quant_qty
						q_qty=0.0
						for main_quant3 in line.split_move_id.reserved_quant_ids:
						# update first record of stock quant to new stock_move with split qty
							if m_quant_qty==quant_qty:
								q_qty = main_quant3.qty - line.split_qty
								m_quant_qty -= main_quant3.qty
								main_quant3.write({'reservation_id':line.id,'qty':line.split_qty})
						for main_quant4 in line.split_move_id.reserved_quant_ids:
						#update remaining qty if qty is there
							if (main_quant4.qty + q_qty)>0 and q_qty !=0:
								q_qty += main_quant4.qty
								main_quant4.write({'qty': q_qty if q_qty > 0 else 0})

				elif quant_qty > (line.product_uom_qty-line.split_qty):	
					#Condition when reseved qty in stock quant is greater than remaining delivery order qty 
					# for transfer remaining qty to new delivery order stock move's stock quant 
					flag=True
					n_quant_qty=quant_qty
					rem_quant = (quant_qty-(line.product_uom_qty-line.split_qty))
					for main_quant2 in line.split_move_id.reserved_quant_ids:
						if main_quant2.qty == rem_quant and n_quant_qty==quant_qty:	#update quant with new stock move when rem_qty is same as requant qty
							main_quant2.write({'reservation_id':line.id,'in_date':date.today()})
							n_quant_qty -= main_quant2.qty
							flag=False
					if flag:
						m_quant_qty=quant_qty
						q_qty=0.0
						for main_quant3 in line.split_move_id.reserved_quant_ids:
						# update first record of stock quant to new stock_move with split rem_qty
							if m_quant_qty==quant_qty:
								q_qty = main_quant3.qty - rem_quant
								m_quant_qty -= main_quant3.qty
								main_quant3.write({'reservation_id':line.id,'qty':rem_quant})
								
						for main_quant4 in line.split_move_id.reserved_quant_ids:
							if (main_quant4.qty + q_qty)>0 and q_qty !=0:
								q_qty += main_quant4.qty
								main_quant4.write({'qty': q_qty if q_qty > 0 else 0})

		 	n_vlas=({'procure_method':line.split_move_id.procure_method,'partner_id':line.split_move_id.partner_id.id,
			'rule_id':line.split_move_id.rule_id.id,'n_sale_line_id':line.split_move_id.n_sale_line_id.id,'name':line.split_move_id.name,
			'sequence':line.split_move_id.sequence,'origin':line.split_move_id.origin,'price_unit':line.split_move_id.price_unit,
			'date':line.split_move_id.date,'priority':line.split_move_id.priority,'warehouse_id':line.split_move_id.warehouse_id.id,
			'picking_type_id':line.split_move_id.picking_type_id.id ,'procurement_id':line.split_move_id.procurement_id.id,
			'group_id':line.split_move_id.group_id.id,'picking_id':res,'product_uom_qty':line.split_qty})
		 	line.write(n_vlas)
		#CH_N080 >>>add code create schedule date record
			self.pool.get('mrp.delivery.date').create(cr,uid,{'n_dispatch_date_d':rec.required_date,
							'n_status':'waiting','n_picking_id':res,
							'n_line_id1':line.split_move_id.n_sale_line_id.id,'n_type':'partial'})
			line.split_move_id.n_sale_line_id._get_schedule_date()
			#CH_N081 <<<<<<<<
                 rec.picking_id.message_post(body='<span style="color:red">Delivery Qty Is Split </span>- New Qty-: '+str(line.rm_qty)+' '+ 'Old Qty:-'+str(line.product_uom_qty))
		 
             for pick in picking_obj.browse(cr, uid, res, context):
                 rec.picking_id.message_post(body='<span style="color:red">New Delivery Order created on split qty</span> - New Delivery Order Number-: '+str(pick.name))
                 pick.write({'parent_pick_id':rec.picking_id.id, 'min_date':rec.required_date})
                 pick.message_post(body='<span style="color:red">Old Delivery Order Number-: </span>'+str(rec.picking_id.name))
             return {
            'name': 'Split delivery Order',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'res_id':res,
            'type': 'ir.actions.act_window_close',
            'target' : 'current',
        }
         
class StockPicking(models.Model):
     _inherit='stock.picking' 
     
     @api.model
     def create(self, vals):
	picking = super(StockPicking, self).create(vals)
        sale=self.env['sale.order'].search([('name','=',picking.origin)], limit=1)
	if sale:
           picking.report_company_name=sale.report_company_name.id
           picking.partner_id=sale.partner_id.id
           picking.partner_shipping_id=sale.partner_shipping_id.id
	return picking

     @api.multi
     def get_customer_credit(self):
	for record in self:
	  if record.partner_id:
	    partner_id = record.partner_id.parent_id if record.partner_id.parent_id else record.partner_id
            n_date=date.strftime(datetime.strptime(partner_id.from_date,'%Y-%m-%d'), '%Y-%m-%d') if partner_id.from_date else ''    
	    n_date1=date.strftime(datetime.strptime(partner_id.to_date,'%Y-%m-%d'), '%Y-%m-%d ') if partner_id.to_date else '' 
	    todate=date.strftime(date.today(),'%Y-%m-%d')  

            if  todate >= n_date  and todate <= n_date1 and partner_id.credit_currency_id:
                record.credit_limit= partner_id.credit_currency_id.compute(partner_id.credit_limit,record.n_quotation_currency_id) 
            else:
                record.credit_limit=0.0
 
#CH_N106 add code to get quotation currency 
     @api.multi
     def _get_sale_currency(self):
	for record in self:
		if record.sale_id:
			record.n_quotation_currency_id=record.sale_id.report_currency_id.id
		else:
			record.n_quotation_currency_id=self.env.user.company_id.currency_id.id

     consignee_id=fields.Many2one('res.partner', string='Consignee To', related='sale_id.partner_id')
     manufactured_id=fields.Many2one('res.company', string='Manufactured By')
     report_currency_id = fields.Many2one('res.currency', related='sale_id.report_currency_id', string="Converted Currency")
     invoice_number=fields.Char(string='Invoice Number')
     origin_id=fields.Many2one('res.country', string='Origin of Goods', default=lambda self: self.env['res.country'].search([('code', '=','AE')]))

     total_gross_weight=fields.Float('Total Net Wt(Kg)', compute='total_gross_weight_val')
     total_net_weight=fields.Float('Total Gross Wt(Kg)', compute='totalweight')
     shipment_mode=fields.Selection([('sea', 'Sea'), ('road', 'Road'), ('air', 'Air')], string="Shipment Mode")
     container_size=fields.Char('Container size')
     container_no=fields.Char('Container No')
     type_of_picking=fields.Selection([('exrprtcart', 'Standard export carton')], string="Type of Picking")
     invoice_ids = fields.Many2many("account.invoice", string='Invoices')

     dispatch_date=fields.Datetime('Dispatch Date')
     #dispatch_doc=fields.Binary(string='Dispatch Document',attachment=True)
     dispatch_doc = fields.Many2many('ir.attachment','dispatch_attachment_rel','dispatch_doc','id','Dispatch Documents')
     dispatch_doc_name = fields.Char(string='Doc Name')

     delivery_date=fields.Datetime('Delivery Date')
     #delivery_doc=fields.Binary('Delivered Receipt',attachment=True)
     delivery_doc = fields.Many2many('ir.attachment','delivery_attachment_rel','delivery_doc','id','Delivered Documents')
     delivery_doc_name = fields.Char(string='Doc Name')
     
     reverse_reason=fields.Selection([('reject', 'Goods Rejected'), ('notdelivered', 'Not Delivered')], string="Reverse  Reason")
     vehicle_number=fields.Many2one('stock.vahicle.number',string='Vehicle Number')
     employee_id=fields.Many2one('hr.employee', string="Driver Name")
     invoice_id=fields.Many2one('account.invoice', 'Invoice Number')

     credit_limit = fields.Float(string="Credit Allowed",readonly=True , compute="get_customer_credit")
     customer_invoice_pending_amt=fields.Float('Other Pending Credit', compute='get_customer_pending_amount', help='Customer Other pntransfer_typeending credit amount')
     amount_total = fields.Float(string='Current Sale Order Remaining Amount', compute='total_sale_amount', help="Total Sale order Amount - current invoice amount")
     credit_bool=fields.Boolean('Credit Bool', compute='amount_bool_check')
     total_delivery_amount=fields.Float('Current Delivery Amount', compute='total_delivery_qty_price_amount', help="Total Current Delivery Order Amount")
     n_quotation_currency_id=fields.Many2one('res.currency','Currency', compute=_get_sale_currency) #related='sale_id.report_currency_id'
     
     parent_pick_id=fields.Many2one('stock.picking', 'Parent Delivery Order')
     order_id=fields.Many2one('sale.order',string="SALE ORDER")
     n_code = fields.Selection([('incoming', 'Suppliers'), ('outgoing', 'Customers'), ('internal', 'Internal')], 'Type of Operation', related='picking_type_id.code')
     qty_exceed=fields.Boolean('Qty Exceed')
     mark_as_final=fields.Boolean('Mark As Final Delivery Order')
     total_current_invoice=fields.Float("Current Order Pending Invoice", compute='totalpendinginvoice' ,help="Current Invoice Amount of sale order ")
     
     is_pending=fields.Boolean(compute='invoice_pend_bool')
     stop_delivery=fields.Boolean('Stop Delivery', compute='stopDeliverycheck')
     allow_delivery=fields.Boolean('Allow Delivery')
     lpo_document_id=fields.Many2many('customer.upload.doc', 'customer_rel' ,'customer_stock_rel',
                     string="PO Number")		# for LPO relation
     split_count=fields.Integer(compute='total_splitdelivery')
     #incoming_doc=fields.Binary('Document Upload', attachment=True)
     incoming_doc = fields.Many2many('ir.attachment','incoming_attachment_rel','incoming_doc','id','Incoming Documents', copy=False)
     purchase_id=fields.Many2one('purchase.order', string='Purchase Order')
     production_id=fields.Many2one('mrp.production', string="Manufacturing No.")
     #request_date_mo=fields.Date('Request on')
     work_order_id=fields.Many2one('mrp.production.workcenter.line')
     request_sch_date_mo=fields.Datetime('Request By', related='work_order_id.date_planned')
     ## add boolean field for print report
     manufactured_by=fields.Char('Manufactured By', default='Aal Mir Plastic Industries ,PO Box 4537, Sharjah, UAE.')
     check_origin=fields.Boolean(default=True) 
     check_manuf=fields.Boolean(default=True)
     check_gross=fields.Boolean()
     check_net=fields.Boolean()
     check_ship=fields.Boolean()
     check_employee=fields.Boolean()
     check_vehicle=fields.Boolean()
     check_invoice=fields.Boolean()
     check_cont_sz=fields.Boolean()
     check_cont_no=fields.Boolean()
     check_picktype=fields.Boolean()
     check_lpo=fields.Boolean()
     partner_shipping_id=fields.Many2one('res.partner',string='Delivery Address')
     check_destination=fields.Boolean(default=False)
     check_hs=fields.Boolean('Print HS Code on Report')
     check_pallet=fields.Boolean('Print Packing/Pallet on Report')
     check_packaging=fields.Boolean('Print Packaging on Report')
     schedule_date=fields.Datetime(related='min_date',string='Scheduled Date')
     check_donumber=fields.Boolean('Print D.O No. on Report',default=True)
     check_date_withcol=fields.Boolean('Print Date With Column on Report',default=True)
     check_date_withnotcol=fields.Boolean('Print Only Date Column on Report')
     check_sale=fields.Boolean('Print SaleOrder No. on Report',default=True)
     check_saleperson=fields.Boolean('Print SalesPerson Name on Report',default=True)
     print_copy=fields.Integer('Report Copies', default=1)
     report_name=fields.Char('Report Name', default='Delivery Order')
     check_term=fields.Boolean(default=True)
     show_stamp=fields.Boolean('Show Stamp on Report',default=True)
     term_of_delivery=fields.Many2one('stock.incoterms',string='Terms', compute='add_term')
     total_qty=fields.Float('Total Qty', compute='totalqty')
     total_pallet=fields.Float('Total Pallet Qty', compute='totalqty')
     total_pack=fields.Float('Total Pack Qty', compute='totalqty')
     ntransfer_type=fields.Selection([('receipt','Receipt'),('dispatch','Dispatch'),('develiry','Delivery'),
     				    ('quality','Quality Check'), ('pre_stock','Move To Stock'),
     				     ('rm_virtual','Raw at Virtual'),('rm_production','RM at Produciton')],
     				      string="Type of Picking")
     customer_name_report=fields.Char('Customer Name on Report',default='Customer Name')
     report_company_name=fields.Many2one('res.company','LetterHead Company Name', default=lambda self: self.env['res.company']._company_default_get('stock.picking'))
     destination_report=fields.Char('Destination on Report', default='Destination')
     check_partner=fields.Boolean(default=True)
     invoice_done=fields.Boolean(default=False)
     #check_vat=fields.Boolean('Print Customer VAT')
     #partner_vat=fields.Char('Customer VAT',related='partner_id.vat_number')
     total_primary_cbm=fields.Char('Primary CBM(M3)', compute='_total_primary_cbm')
     total_secondary_cbm=fields.Char('Total Order CBM(M3)', compute='_total_secondary_cbm')    
     packaging_info=fields.Text(compute='_empty_pack_info')
     secondary_weight=fields.Text(compute='_empty_pack_info', string='Secondary Weight')
     check_lpo_line=fields.Boolean('Print LPO No. in Product Line',default=False)
     check_primary_cbm=fields.Boolean(default=False)
     check_secondary_cbm=fields.Boolean(default=False)

     @api.multi
     @api.depends('origin')
     def add_term(self):
        for record in self:
            if record.origin:
               sale=self.env['sale.order'].search([('name','=',record.origin)], limit=1)
               if sale:
                  record.term_of_delivery=sale.incoterm.id
               purchase=self.env['purchase.order'].search([('name','=',record.origin)], limit=1)
               if purchase:
                  record.term_of_delivery=purchase.incoterm_id.id
     @api.multi
     @api.depends('pack_operation_product_ids.primary_cbm','pack_operation_product_ids.secondary_cbm')
     def _empty_pack_info(self):
         for record in self:
            info=''
            weight=0.0
            for pack in record.pack_operation_product_ids:
                for packg in pack.product_id.packaging_ids:
                    if packg:
                       if packg.pkgtype =='secondary':
                          weight +=(pack.net_weight) + (pack.total_pallet_qty * packg.uom_id.product_id.weight)
                record.secondary_weight=weight
                if not pack.primary_cbm: 
                   info +="Primay Packaging:   "+  str(pack.product_id.name )+"\n"
               
                if not pack.secondary_cbm:
                   info +="Secondary Packaging:  "+ str(pack.product_id.name )+"\n"
                else:
                   info +=""

            record.packaging_info=info

     @api.multi
     @api.depends('pack_operation_product_ids.primary_cbm','pack_operation_product_ids.secondary_cbm')
     def _total_primary_cbm(self):
        for record in self: 
            total_pm_cbm=0.0
            for pack in record.pack_operation_product_ids:
                if pack.primary_cbm:
                   total_pm_cbm +=round(pack.primary_cbm,4)
                else:
                   total_pm_cbm =0.0
            record.total_primary_cbm=total_pm_cbm

     @api.multi
     @api.depends('pack_operation_product_ids.secondary_cbm')
     def _total_secondary_cbm(self):
        for record in self:
            total_sc_cbm=0.0
            for pack in record.pack_operation_product_ids:
                if pack.secondary_cbm:
                   total_sc_cbm +=round(pack.secondary_cbm,4)
                else:
                   total_sc_cbm =0.0
                  
            record.total_secondary_cbm=float(total_sc_cbm) + float(record.total_primary_cbm) 

     @api.multi
     @api.depends('pack_operation_product_ids.product_qty','pack_operation_product_ids.qty_done', 'pack_operation_product_ids.total_pallet_qty','pack_operation_product_ids.pack_qty')
     def totalqty(self):
        for record in self:
            if record.pack_operation_product_ids:
               total=0.0
               for line in record.pack_operation_product_ids:
                   if line.product_id.type != 'service':
                      total +=line.qty_done if line.qty_done else line.product_qty
               record.total_qty=total
               record.total_pack=sum(line.pack_qty for line in record.pack_operation_product_ids)
               record.total_pallet=sum(line.total_pallet_qty for line in record.pack_operation_product_ids)
     	             
     @api.multi
     @api.depends('pack_operation_product_ids.net_weight')
     def totalweight(self):
        for record in self:
            if record.pack_operation_product_ids:
               record.total_net_weight=sum(line.net_weight for line in record.pack_operation_product_ids)
            else:
                record.total_net_weight=0.0
                
     @api.multi
     def amount_bool_check(self):
         for record in self:
	     if record.n_code == 'outgoing' and record.state not in ('transit','done','delivered','cancel'):
	     	if not record.sale_id.cr_state:
			total_amount=record.customer_invoice_pending_amt + record.total_current_invoice
			if total_amount > record.credit_limit:
                           if record.allow_delivery==True:
				record.credit_bool =False
			   elif record.sale_id.stop_delivery == True:
			       	record.credit_bool =True
			   else:
				 record.credit_bool =False 
			  # if record.allow_delivery==True:
			   #	record.credit_bool =False
			  # else:
			   #	record.credit_bool =True	
			else:
			   record.credit_bool =False
	     	else:
		     total_amount=record.customer_invoice_pending_amt + record.amount_total
		     if total_amount > record.credit_limit:
			   if record.allow_delivery==True:
				record.credit_bool =False
			   elif record.sale_id.stop_delivery == True:
			       	record.credit_bool =True
			   else:
				 record.credit_bool =False 
		     else:
			   record.credit_bool =False
	     else:
		record.credit_bool =False
            
     @api.multi
     def stopDeliverycheck(self):
         for record in self:
             if record and record.n_code == 'outgoing' and record.sale_id.cr_state == 'request':
                
                record.stop_delivery=record.sale_id.stop_delivery
             else:
                record.stop_delivery=False
             
     @api.multi
     @api.depends('sale_id')
     def totalpendinginvoice(self):
         for record in self:
	     if record.sale_id:
		     invoice=self.env['account.invoice'].search([('sale_id', '=', record.sale_id.id)])
		     if invoice:
		        total_pay_amt1=0.0
		        currency_id=record.n_quotation_currency_id if record else self.env.user.company_id.currency_id
		        for inv in invoice:
		            if inv.state in ('open', 'paid'):
		               d = json.loads(inv.payments_widget)
		               if d:
		                  for payment in d['content']:
		                    total_pay_amt1 += inv.currency_id.compute((payment['amount']),currency_id)
                               else:
                                    total_pay_amt1 += inv.currency_id.compute(inv.amount_total,currency_id)
                              
                       
			if  record.sale_id.converted_amount_total >= total_pay_amt1 :                 
		        	record.total_current_invoice=record.sale_id.converted_amount_total - total_pay_amt1 
			else:
				record.total_current_invoice=0.0

     @api.multi
     def send_block_rqst(self):
         for record in self:
             credit=self.env['res.partner.credit'].search([('sale_id','=',record.sale_id.id),('state','=','approve')])
             if credit:
                for cr in credit:
                    cr.partner_id.message_post(body='Credit Block Request from Delivery:  '+str(record.name))
                    cr.state='request'
                    cr.deliery_note='Please Unblock Credit Request of Delivery No.'+str(record.name)
                    cr.delivery_id=record.id
                record.message_post(body="Credit Request Send to Accountant")
             else:
                credit_rqst=self.env['res.partner.credit'].search([('sale_id','=',record.sale_id.id),('delivery_id','=',record.id),
                                                            ('state','=','request')])
                if credit_rqst:
                   for cr_rqst in credit_rqst:
                       cr_rqst.partner_id.message_post(body='please Check Credit Request '+' '+str(cr_rqst.delivery_id.name)+ 'Date   '+str(date.today()))
                       cr_rqst.deliery_note= 'please Check Credit Request ' +str(date.today())
                else:
                    if record.partner_id.parent_id:
                       record.partner_id.parent_id.write({'crdit_ids': [(0, 0, {
				'sale_id': record.sale_id.id,
				'sale_amount': record.sale_id.amount_total,
				'credit_ask': 0.0,
				'inv_paid': 0.0 ,
                                'partner_id':record.partner_id.parent_id.id,
                                'state':'request',
                                'delivery_id':record.id
		               })]})
                       record.partner_id.parent_id.message_post(body="Credit Request Send to Accountant  for Delivery Order:"+str(record.name))
                    else:
                        record.partner_id.write({'crdit_ids': [(0, 0, {
				'sale_id': record.sale_id.id,
				'sale_amount': record.sale_id.amount_total,
				'credit_ask': 0.0,
				'inv_paid': 0.0 ,
                                'partner_id':record.partner_id.id,
                                'state':'request',
                                'delivery_id':record.id
		               })]})
                        record.partner_id.message_post(body="Credit Request Send to Accountant  for Delivery Order:"+str(record.name))
                    record.message_post(body="Credit Request Send to Accountant")
             record.allow_delivery=False         

     @api.multi
     def credit_rqst_stock(self):
        for line in self:
            move_tree = self.env.ref('gt_order_mgnt.customer_credit_tree', False)
            move_form = self.env.ref('gt_order_mgnt.customer_credit_form', False)
            if move_tree:
                return {
                    'type': 'ir.actions.act_window',
                    'view_type': 'form',
                    'view_mode': 'tree',
                    'res_model': 'res.partner.credit',
                    'views': [(move_tree.id, 'tree'), (move_form.id, 'form')],
                    'view_id': move_tree.id,
                    'target': 'current',
                    'domain':[('sale_id','=',self.sale_id.id)],
                }

        return True
     
     @api.multi
     @api.depends('total_current_invoice')
     def invoice_pend_bool(self):
         for record in self:
             if record and record.total_current_invoice > 0.0:
                record.is_pending=True
     @api.multi
     def total_splitdelivery(self):
         for record in self:
             split=self.env['stock.picking'].search([('parent_pick_id', '=', record.id)])  
             if split:
                record.split_count=len(split)       
     @api.multi
     def action_child_delivery(self):
	do_tree = self.env.ref('stock.vpicktree', False)
	do_form = self.env.ref('stock.view_picking_form', False)
        if do_form:
            return {
		'name':"Split Delivery orders History",
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'tree',
                'res_model': 'stock.picking',
		'views': [(do_tree.id, 'tree'), (do_form.id, 'form')],
                'view_id': do_tree.id,
                'target': 'current',
		'domain':[('parent_pick_id', '=', self.id)],
            }

     @api.multi
     def split_picking_data(self):
	order_form = self.env.ref('gt_order_mgnt.view_picking_form_split_aalmir', False)
	context = self._context.copy()
        list_l=[]  
        list_pack=[]
        for line in self.move_lines:
            list_l.append((0,0,{'product_id':line.product_id.id, 'state':line.state,'product_uom_qty':line.product_uom_qty
                                , 'product_uom':line.product_uom.id, 'name':line.name, 'location_id':line.location_id.id,
                                    'location_dest_id':line.location_dest_id.id,'split_move_id':line.id}))
     
	context.update({'default_move_line_id':list_l, 'default_picking_id':self.id })
        
        return {
            'name':'Split Main Delivery Order',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'stock.picking.split',
            'views': [(order_form.id, 'form')],
            'view_id': order_form.id,
            'target': 'new',
	    'context':context,
       }
       
     @api.multi
     def do_transfer(self):			#change to do_new_transfer
        return_val = super(StockPicking, self).do_transfer() 
        invoice_val=self.env['account.invoice']
        account_line=self.env['account.invoice.line']
        journal_id = invoice_val.default_get(['journal_id'])['journal_id']
        invoice_picking_ids = []
        for rec in self:
            if rec.picking_type_id.code == 'outgoing' and rec.sale_id:
                for move in rec.pack_operation_product_ids:
                     if move.n_sale_order_line.product_uom_qty < move.n_sale_order_line.qty_delivered :                    
                        rec.qty_exceed=True
                if rec.sale_id.auto_invoice:
                    journal_id = invoice_val.default_get(['journal_id'])['journal_id']
                    invoice =invoice_val.create({'partner_id':rec.sale_id.partner_id.id,
                                             'partner_invoice_id':rec.sale_id.partner_invoice_id.id,
                                             'name': rec.sale_id.name,  'origin': rec.sale_id.name,
                                             'type': 'out_invoice','journal_id': journal_id,
                                             'n_lpo_receipt_date':rec.sale_id.lpo_receipt_date,
                                             'n_lpo_issue_date':rec.sale_id.lpo_issue_date,
                                             'n_lpo_document':rec.sale_id.lpo_document,
                                             'document_id':[(6, 0, [x.id for x in  rec.lpo_document_id])],
                                             'currency_id':rec.sale_id.n_quotation_currency_id.id if rec.sale_id.n_quotation_currency_id
                                                    else rec.sale_id.currency_id.id ,
                                             'user_id': rec.sale_id.user_id and rec.sale_id.user_id.id,    
                                             'team_id': rec.sale_id.team_id.id, 'sale_id':rec.sale_id.id,
                                             'account_id': rec.sale_id.partner_invoice_id.property_account_receivable_id.id,
                                             'payment_term_id': rec.sale_id.payment_term_id.id,
                                             'fiscal_position_id': rec.sale_id.fiscal_position_id.id or  rec.sale_id.partner_invoice_id.property_account_position_id.id })
                    
		    account=False #just assign
                    rec.invoice_ids=[(6, 0, [x.id for x in invoice])]
                    invoice.picking_ids=[(6, 0, [x.id for x in rec])]
                    invoice.date_due=invoice.payment_date_inv
                    for line in rec.pack_operation_product_ids: 
                        for sale_line in rec.sale_id.order_line:
                            if line.product_id.id == sale_line.product_id.id:
                               account = line.product_id.property_account_income_id or line.product_id.categ_id.property_account_income_categ_id
                               inv_line=account_line.create({'invoice_id':invoice.id,
                                  'product_id':line.product_id.id, 
                                  'quantity':line.qty_done,
                                  'lpo_documents':line.lpo_documents,
                                  'invoice_line_tax_ids': [(6, 0, [x.id for x in  line.n_sale_order_line.tax_id])],
                                  'uom_id':line.product_uom_id.id,
                                  'name':line.product_id.name, 
                                  'price_unit':line.n_sale_order_price,
                                  'account_id':line.product_id.property_account_income_id.id or line.product_id.categ_id.property_account_income_categ_id.id,})
                               inv_line.write({'sale_line_ids': [(6, 0, [line.n_sale_order_line.id])]})
                            else:
                               if sale_line.qty_invoiced < sale_line.product_uom_qty and sale_line.product_id.type =='service': 
                                   inv_line=account_line.create({'invoice_id':invoice.id,
                                      'product_id':sale_line.product_id.id, 
                                      'quantity':(sale_line.product_uom_qty - sale_line.qty_invoiced),
                                      'lpo_documents':line.lpo_documents,
                                      'invoice_line_tax_ids': [(6, 0, [x.id for x in  sale_line.tax_id])],
                                      'uom_id':sale_line.product_uom.id,
                                      'name':sale_line.product_id.name, 
                                      'price_unit':sale_line.price_unit,
                                      'account_id':sale_line.product_id.property_account_income_id.id or sale_line.product_id.categ_id.property_account_income_categ_id.id,})
                                   inv_line.write({'sale_line_ids': [(6, 0, [sale_line.id])]})
                    invoice.compute_taxes()
            if rec.picking_type_id.code == 'incoming' and rec.purchase_id and not  rec.purchase_id.payment_term_id.advance_per and not rec.purchase_id.milestone_ids:
               journal = self.env['account.journal'].search([('type', '=', 'purchase')], limit=1) 
               invoice=self.env['account.invoice'].create({'purchase_id':rec.purchase_id.id, 
                     'type': 'in_invoice','origin':rec.purchase_id.name,
                     'account_id':rec.partner_id.property_account_payable_id.id,
                     'partner_id':rec.partner_id.id,'payment_term_id':rec.purchase_id.payment_term_id.id,
                     'journal_id':journal.id,'currency_id':rec.purchase_id.currency_id.id})
               invoice_line = self.env['account.invoice.line']
               for line in rec.pack_operation_product_ids:
                   for p_line in rec.purchase_id.order_line:
                        if line.product_id.id == p_line.product_id.id and line.qty_done:
                           account = invoice_line.get_invoice_line_account('in_invoice', p_line.product_id, rec.purchase_id.fiscal_position_id, self.env.user.company_id)
			   inv_line =invoice_line.create({
					    'purchase_line_id': p_line.id,
		                            'invoice_id':invoice.id,
					    'name': p_line.name,
					    'origin': rec.purchase_id.origin,
					    'uom_id': p_line.product_uom.id,
					    'product_id': p_line.product_id.id,
					    'account_id': invoice_line.with_context({'journal_id': journal.id, 'type': 'in_invoice'})._default_account(),
					    'price_unit': p_line.order_id.currency_id.compute(p_line.price_unit, rec.purchase_id.currency_id, round=False),
					    'quantity': line.qty_done,
					    'discount': 0.0,
		                            'account_id':account.id,
					    'account_analytic_id': p_line.account_analytic_id.id,
                                            'invoice_line_tax_ids': [(6, 0, [x.id for x in  p_line.taxes_id])],
					})
                        else:
                            if not p_line.qty_invoiced and p_line.product_id.type == 'service':
                               inv_line_service =invoice_line.create({
					    'purchase_line_id': p_line.id,
		                            'invoice_id':invoice.id,
					    'name': p_line.name,
					    'origin': rec.purchase_id.origin,
					    'uom_id': p_line.product_uom.id,
					    'product_id': p_line.product_id.id,
					    'account_id': invoice_line.with_context({'journal_id': journal.id, 'type': 'in_invoice'})._default_account(),
					    'price_unit': p_line.order_id.currency_id.compute(p_line.price_unit, rec.purchase_id.currency_id, round=False),
					    'quantity': p_line.product_qty,
					    'discount': 0.0,
		                            'account_id':account.id,
					    'account_analytic_id': p_line.account_analytic_id.id,
                                            'invoice_line_tax_ids': [(6, 0, [x.id for x in  p_line.taxes_id])],
					})
               invoice.compute_taxes()
               rec.invoice_ids=[(6, 0, [x.id for x in invoice])]
               invoice.picking_ids=[(6, 0, [x.id for x in rec])]
               invoice.date_due=invoice.payment_date_inv
            if rec.picking_type_id.code == 'incoming' and rec.purchase_id and rec.purchase_id.payment_term_id.advance_per or rec.purchase_id.milestone_ids:
               invoice_line = self.env['account.invoice.line']
               p_invoice=self.env['account.invoice']
               journal = self.env['account.journal'].search([('type', '=', 'purchase')], limit=1) 
               invoice=p_invoice.search([('origin','=',rec.purchase_id.name)],limit=1)
               new_invoice=False
               if invoice.state == 'paid':
                  new_invoice=p_invoice.create({'purchase_id':rec.purchase_id.id, 
                              'type': 'in_invoice','origin':rec.purchase_id.name,
                              'account_id':rec.partner_id.property_account_payable_id.id,
                              'partner_id':rec.partner_id.id,
                              'payment_term_id':rec.purchase_id.payment_term_id.id,
                              'journal_id':journal.id,
                              'currency_id':rec.purchase_id.currency_id.id})
               for line in rec.pack_operation_product_ids:
                   for p_line in rec.purchase_id.order_line:
                       account = invoice_line.get_invoice_line_account('in_invoice', p_line.product_id, rec.purchase_id.fiscal_position_id, self.env.user.company_id)
                       if line.product_id.id == p_line.product_id.id:
                          if p_line.qty_received > p_line.product_qty:
                             if invoice.state == 'draft':
                                for inv_line in invoice.invoice_line_ids:
                                    if inv_line.product_id.id == p_line.product_id.id:
                                       inv_line.write({'quantity':inv_line.quantity +(p_line.qty_received - p_line.product_qty)}) 
                                       p_line.write({'qty_invoiced':p_line.qty_invoiced+(p_line.qty_received - p_line.product_qty)})
                                invoice.compute_taxes()
                             if new_invoice:
                                inv_line =invoice_line.create({
					    'purchase_line_id': p_line.id,
		                            'invoice_id':new_invoice.id,
					    'name': p_line.name,
					    'origin': rec.purchase_id.origin,
					    'uom_id': p_line.product_uom.id,
					    'product_id': p_line.product_id.id,
					    'account_id': invoice_line.with_context({'journal_id': journal.id, 'type': 'in_invoice'})._default_account(),
					    'price_unit': p_line.order_id.currency_id.compute(p_line.price_unit, rec.purchase_id.currency_id, round=False),
					    'quantity': (p_line.qty_received - p_line.product_qty),
					    'discount': 0.0,
		                            'account_id':account.id,
					    'account_analytic_id': p_line.account_analytic_id.id,
                                            'invoice_line_tax_ids': [(6, 0, [x.id for x in  p_line.taxes_id])],
					})
                                new_invoice.compute_taxes()
                             print"yyyyyyyyyyyyyy",invoice.state, invoice.payment_move_line_ids
			     if invoice.state == 'open':
                                move_id=[]
                                if invoice.payment_move_line_ids:
                                   for move_line in invoice.payment_move_line_ids:
                                       move_id.append(move_line.id)
                                       res=move_line.remove_move_reconcile()
                                invoice.action_cancel()
                                invoice.action_cancel_draft()
                                for inv_line in invoice.invoice_line_ids:
                                    if inv_line.product_id.id == p_line.product_id.id:
                                       inv_line.write({'quantity':inv_line.quantity +(p_line.qty_received - p_line.product_qty)}) 
                                       p_line.write({'qty_invoiced':p_line.qty_invoiced+(p_line.qty_received - p_line.product_qty)})
                                invoice.compute_taxes()
                                '''if move_id:
                                   invoice.invoice_validate()
                                   move_line=self.env['account.move.line'].search([('id','in',move_id)])
                                   print"ttttttttt",move_line
                                   if move_line:
                                      for m_line in move_line:
                                          print"uiiiiii",m_line
                                          add=invoice.register_payment(m_line)
                                          print"yyyyyy",'''
        return return_val     
 
     @api.multi
     @api.depends('sale_id')
     def total_sale_amount(self):
         for record in self:
             total_inv=0.0
             if record.sale_id:
                if record.sale_id.invoice_ids:
                   for invoice in record.sale_id.invoice_ids:
                       if invoice.state in ('open','draft', 'paid'):
                          d = json.loads(invoice.payments_widget)
                          if d:
                            for payment in d['content']:
                               total_inv +=invoice.currency_id.compute(payment['amount'],record.n_quotation_currency_id)
			       
		   if record.sale_id.converted_amount_total >= total_inv:
			record.amount_total=record.sale_id.converted_amount_total - total_inv
		   else:
                   	record.amount_total=0.0
                else:
                    record.amount_total=record.sale_id.converted_amount_total

     @api.multi
     @api.depends('pack_operation_product_ids.price_subtotal')
     def total_delivery_qty_price_amount(self):
         for record in self:
             amount=0.0#sum(record.line.price_subtotal 
	     for line in record.pack_operation_product_ids:
		currency=record.sale_id.n_quotation_currency_id if record.sale_id else self.env.user.company_id.currency_id
		if currency:
			amount+=currency.compute(line.price_subtotal,record.n_quotation_currency_id)
	     record.total_delivery_amount=amount
    
     @api.multi
     def get_customer_pending_amount(self):
         for record in self:
	    if record.picking_type_id.code == 'outgoing' and record.sale_id and record.state not in ('transit','done','delivered','cancel'):
                credit_currency_id=record.partner_id.credit_currency_id if record.partner_id.credit_currency_id else self.env.user.company_id.currency_id
                for record in self:
                     total=0.0
                     partner_id=[record.sale_id.partner_id.id]
		     for prtn in self.env['res.partner'].search([('parent_id','=',record.sale_id.partner_id.id)]):
			 partner_id.append(prtn.id)
                     invoice=self.env['account.invoice'].search([('state','=','open'),('sale_id', '!=', record.sale_id.id),('partner_id','in',tuple(partner_id))])
                     if invoice:
                        pay=0.0
                        for inv in invoice:
                            total += inv.residual_new1
                        record.customer_invoice_pending_amt=inv.currency_id.compute((total),credit_currency_id)
            else:
                record.customer_invoice_pending_amt=0.0           

     @api.multi
     def aalmir_picking_print(self):
        self.ensure_one()
        self.write({'printed': True})
        return self.env['report'].get_action(self, 'gt_order_mgnt.report_delivery_aalmir')
               
     @api.multi
     @api.depends('pack_operation_product_ids.gross_weight')
     def total_gross_weight_val(self):
        for record in self:
            if record.pack_operation_product_ids:
               record.total_gross_weight=sum(line.gross_weight for line in record.pack_operation_product_ids)
            else:
                record.total_gross_weight=0.0
	    '''ids=[]
            for move in record.pack_operation_product_ids:
		if move.qty_done:
			if move.product_uom_id.name == 'Kg':
				ids.append(move.qty_done)
			else:
				ids.append(move.gross_weight)
		else:
				ids.append(move.gross_weight)
            record.total_gross_weight = sum(ids)'''
 
     #### Add invoice history in stock vml
     @api.multi
     def open_invoices_history(self):
        for line in self:
            if not line.invoice_ids:
                raise UserError('No Invoices available!')
            invoice_tree = self.env.ref('account.invoice_tree', False)
            invoice_form = self.env.ref('account.invoice_form', False)
            if invoice_tree:
                return {
                    'type': 'ir.actions.act_window',
                    'view_type': 'form',
                    'view_mode': 'tree',
                    'res_model': 'account.invoice',
                    'views': [(invoice_tree.id, 'tree'), (invoice_form.id, 'form')],
                    'view_id': invoice_tree.id,
                    'target': 'current',
                    'domain':[('id','in',line.invoice_ids.ids)],
                }
        return True

class StockPackOperation(models.Model):
     _inherit='stock.pack.operation' 
    
     @api.model
     def create(self,vals):
	picking_id=vals.get('picking_id')
	product_id=vals.get('product_id')
	if product_id and picking_id and not vals.get('n_sale_order_line'):
		line_id=self.env['stock.move'].search([('picking_id','=',picking_id),('product_id','=',product_id)],limit=1)
                p_name=''
		if line_id.n_sale_line_id:
			vals.update({'n_sale_order_line':line_id.n_sale_line_id.id})
	return super(StockPackOperation,self).create(vals)
	
     gross_weight=fields.Float('Net Weight(Kg)', compute='grossweight')## add new field gross weight
     net_weight=fields.Float('Gross Weight(Kg)', compute='netweight')## add new field net weight
     #n_reserve_qty = fields.Float('Reserved Qty',compute='_get_reserve_qty')#digits_compute=dp.get_precision('Product')

     product_hs_code=fields.Char('HS Code', related='product_id.product_hs_code')
     packaging_id=fields.Many2one('product.packaging' ,string='Packaging', compute='product_packaging')
     pack_qty=fields.Integer('Packaging Qty', compute='product_packaging')
     pallet_no=fields.Float('Packing/Pallet', compute='total_pkg_pallet')
     total_pallet_qty=fields.Float('Total No. of Pallets', compute='total_pkg_pallet')
     secondary_pack=fields.Many2one('product.packaging' ,string='Second Packaging', compute='product_packaging')

#CH_N055 add fields to get date history and proper values start >>>
     n_sale_order_line =fields.Many2one('sale.order.line','Sale order line')
     n_sale_order_price =fields.Float('Price',related='n_sale_order_line.price_unit')
     price_subtotal=fields.Float('Price Subtotal', compute='total_price_amount')
#CH_N074>>
     #n_code = fields.Selection([('incoming', 'Suppliers'), ('outgoing', 'Customers'), ('internal', 'Internal')], 'Type of Operation', related='picking_id.n_code')
     #extra_qty_delivered=fields.Float(compute='_delivered_extra_qty', string='Extra Qty Delivered')
     lpo_documents=fields.Many2many('customer.upload.doc','sale_order_line_pack_rel','pack_id','doc_id',string='LPO Documents')
     primary_cbm=fields.Float('Primary CBM(M3)', compute='cal_primary_cbm')
     secondary_cbm=fields.Float('Secondary CBM(M3)', compute='cal_primary_cbm')
     external_no=fields.Char('External No.', compute='product_ext_no')

     @api.multi
     @api.depends('product_id')
     def product_ext_no(self):
        for record in self:
            if record.product_id:
               pricelist=self.env['product.pricelist'].search([('customer','=',record.picking_id.partner_id.id)])
               if pricelist:
                  for plist in pricelist:
                      if plist.currency_id.id == record.picking_id.sale_id.currency_id.id:
                         cust=self.env['customer.product'].search([('product_id','=',record.product_id.id),('pricelist_id','=',plist.id)])
                         if cust:
                            record.external_no=cust.ext_product_number
                         else:
                            record.external_no=str("NA")

     @api.multi
     @api.depends('product_id.packaging_ids','pack_qty')
     def cal_primary_cbm(self):
        for record in self: 
    		for packg in record.product_id.packaging_ids:
                    if packg.pkgtype == 'primary':
                       length=self.env['n.product.discription'].search([('attribute.name','=','Length'),('product_id','=',packg.uom_id.product_id.product_tmpl_id.id)], limit=1)
                       width=self.env['n.product.discription'].search([('attribute.name','=','Width'),('product_id','=',packg.uom_id.product_id.product_tmpl_id.id)], limit=1)
                       height=self.env['n.product.discription'].search([('attribute.name','=','Height'),('product_id','=',packg.uom_id.product_id.product_tmpl_id.id)], limit=1)
                       print"(Primary Cbm",length.value, width.value,height.value,record.pack_qty,(((float(length.value) * float(width.value) * float(height.value)) * record.pack_qty)/1000000),record.product_id.name, record.picking_id.name
		       record.primary_cbm=((float(length.value) * float(width.value) * float(height.value)) * record.pack_qty)/1000000
                    if packg.pkgtype == 'secondary':
                       length=self.env['n.product.discription'].search([('attribute.name','=','Length'),('product_id','=',packg.uom_id.product_id.product_tmpl_id.id)], limit=1)
                       width=self.env['n.product.discription'].search([('attribute.name','=','Width'),('product_id','=',packg.uom_id.product_id.product_tmpl_id.id)], limit=1)
                       height=self.env['n.product.discription'].search([('attribute.name','=','Height'),('product_id','=',packg.uom_id.product_id.product_tmpl_id.id)], limit=1)
                       print"(Secondary CBM",length.value, width.value,height.value,record.total_pallet_qty,(((float(length.value) * float(width.value) * float(height.value)) * record.total_pallet_qty)/1000000), record.product_id.name
		       record.secondary_cbm=((float(length.value) * float(width.value) * float(height.value)) * record.total_pallet_qty)/1000000   

     @api.multi
     @api.depends('product_id.packaging_ids','product_qty','qty_done')
     def product_packaging(self):
        for record in self: 
            #if record.picking_id.state not in ('transit','done','delivered','cancel'):
    		for packg in record.product_id.packaging_ids:
            		if packg.pkgtype == 'primary':
				record.packaging_id =packg.id
                                if packg.qty:
				   record.pack_qty=math.ceil((record.qty_done if record.qty_done else record.product_qty) /packg.qty)
			if packg.pkgtype == 'secondary':
				record.secondary_pack =packg.id
				#record.pack_qty=math.ceil((record.qty_done if record.qty_done else record.product_qty) /packg.qty)
				#break
				#break
               
     @api.multi
     @api.depends('pack_qty')
     def total_pkg_pallet(self):
        for record in self:
        	#if record.picking_id.state not in ('transit','done','delivered','cancel'):
        		if record.pack_qty :
				for packg in record.product_id.packaging_ids:
		           		if packg.pkgtype == 'secondary':
		              			record.pallet_no = packg.qty
               					record.total_pallet_qty=math.ceil(record.pack_qty/packg.qty)
               
     #@api.multi
     #@api.depends('product_id','product_qty','qty_done')
     #def totalpack_qty(self):
     #   for record in self:
     #       if record.product_id.packaging_ids:
     #          record.pack_qty=math.ceil((record.qty_done if record.qty_done else record.product_qty) /record.product_id.packaging_ids[0].qty)

     #@api.multi
     #@api.depends('product_id','product_qty', 'qty_done', 'product_id.packaging_ids')
     #def pallet_qty(self):
     #   for record in self:
     #   	if record.picking_id.state not in ('transit','done','delivered','cancel'):
     #          		for packg in record.product_id.packaging_ids:
     #              		if packg.pkgtype == 'secondary':
     #                 			record.pallet_no = packg.qty
      
     @api.multi
     @api.depends('product_id','product_qty', 'qty_done',)
     def netweight(self):
        for record in self:
            if record.packaging_id:
                record.net_weight=record.gross_weight +(record.pack_qty *record.packaging_id.uom_id.product_id.weight)
		#pack_qty=((record.qty_done if record.qty_done else record.product_qty) /record.packaging_id.qty)
              	#record.net_weight=((pack_qty) * record.packaging_id.weight )
                      
     @api.multi
     @api.depends('product_id','product_qty', 'qty_done', 'product_id.weight')
     def grossweight(self):
        for record in self:
            if record.product_id.weight:
               record.gross_weight=((record.qty_done if record.qty_done else record.product_qty) * record.product_id.weight )
            else:
               record.gross_weight=0.0

     @api.multi
     @api.depends('product_qty', 'n_sale_order_price', 'qty_done')
     def total_price_amount(self):
         for record in self:
             if not record.qty_done:
                record.price_subtotal= record.product_qty * record.n_sale_order_price 
             if record.qty_done:
                record.price_subtotal= record.qty_done * record.n_sale_order_price
             if record.qty_done and record.product_qty:
                record.price_subtotal= record.qty_done * record.n_sale_order_price

     @api.multi
     def save(self):
     	pass
	#if self.n_code == 'outgoing':
	#	if self.qty_done > self.n_reserve_qty:
	#		raise UserError(_("Please enter proper quantity"))


#CH_N055
class stockBackorderConfirmation(models.TransientModel):
    _inherit = 'stock.backorder.confirmation'

    @api.multi
    def _process(self, cancel_backorder=False):
        self.ensure_one()
	super(stockBackorderConfirmation,self)._process(cancel_backorder)
        if not cancel_backorder:
		backorder_pick = self.env['stock.picking'].search([('backorder_id', '=', self.pick_id.id)])
		for rec in backorder_pick:
			for line in rec.move_lines:
				self.env['mrp.delivery.date'].create({'n_dispatch_date_d':rec.min_date,
										'n_status':'waiting',
										'n_picking_id':rec.id,'n_type':'full',
										'n_line_id1':line.n_sale_line_id.id})
				line.n_sale_line_id._get_schedule_date()	


class stock_move_scrap(models.Model):
    _inherit = "stock.move.scrap"
    _description = "Scrap Products"

    scrap_reason=fields.Selection([('reject','Quality not Good'),('min','Quantity is Less' )], string="Scrap Reason")
    uploaded_documents = fields.Many2many('ir.attachment','scrap_attachment_rel','scrap_doc','id','Scrap Documents')
    available_qty = fields.Float('Available Qty')
    #mrp_id=fields.Many2one('mrp.production', string="MRP")
    
    @api.multi
    def move_scrap(self):
        obj = self.env['stock.move'].browse(self._context.get('active_id'))
        picking = self.env['stock.picking'].browse(self._context.get('active_id'))
	if self.product_qty > obj.product_qty:
		raise UserError(_("Please Enter Quantity less than or equal availabel Quantity"))
        if self.scrap_reason:
           obj.scrap_reason=self.scrap_reason
	#CH_N118 add code for quantity update
        if self.uploaded_documents:
	   search_ids=self.env['mrp.production'].search([('name','=',obj.name)])
	   if search_ids:
           	search_ids.uploaded_documents=self.uploaded_documents
	obj.product_uom_qty -= self.product_qty
	scrp_qty=self.product_qty
	res = super(stock_move_scrap, self).move_scrap()
        return res
#CH_N0#55 end<<<<<

    @api.model
    def default_get(self, fields):
        result= super(stock_move_scrap, self).default_get(fields)
        obj = self.env['stock.move'].browse(self._context.get('active_id'))
	if obj:
            result.update({'available_qty':obj.product_uom_qty if obj.product_uom_qty else 0.0})
        return result
        
class stockQuant(models.Model):
    _inherit = 'stock.quant' 
     
    @api.multi
    def write(self,vals):
    	print "quants....write",vals,self
        return super(stockQuant, self).write(vals)
    	
    @api.model
    def create(self,vals):
    	res = super(stockQuant, self).create(vals)
    	print "quant..Create..",vals,res
        return res

#Inherite Method to update quantity in quants
    @api.v7
    def quants_get_preferred_domain(self, cr, uid, qty, move, ops=False, lot_id=False, domain=None, preferred_domain_list=[], context={}):
    	print "-----------quants_get_preferred_domain..order_mgnt",context
	if context.get('sale_support'):
		qty=context.get('res_qty')
        return super(stockQuant,self).quants_get_preferred_domain(cr, uid, qty, move, ops, lot_id, domain, preferred_domain_list, context)
        
        
class StockProductionLot(models.Model):
    _inherit='stock.production.lot'
    
    batch_ids=fields.One2many('mrp.order.batch.number','lot_id', string='Batch Details')
    production_id=fields.Many2one('mrp.production','Manufacturing No.')
    total_qty=fields.Float('Total Qty')
    product_uom_id=fields.Many2one('product.uom','Unit of Measure')

    @api.multi
    @api.depends('quant_ids')
    def total_lot_qty(self):
        for record in self:
            if record.quant_ids:
               record.total_qty=sum(line.qty for line in record.quant_ids)
               record.product_uom_id=record.quant_ids[0].product_uom_id.id
               
    '''@api.model
    def default_get(self, fields):
        result= super(StockProductionLot, self).default_get(fields)
        code=''
        if result.get('product_id'):
           if product.categ_id.cat_type == 'film':
              code='FILM'
           if product.categ_id.cat_type == 'injection':
              code='INJ'
           result.update({'name':code + str(result.get('name'))})
        return result'''
    '''@api.model
    def create(self, vals):
        result = super(StockProductionLot, self).create(vals)
        if vals.get('name'):
           code=''
           if result.product_id.categ_id.cat_type == 'film':
              code='FILM'
           if result.product_id.categ_id.cat_type == 'injection':
              code='INJ'
           result.name=code+vals.get('name')
        return result'''
        
class StockMoveOperationLink(models.Model):
    _inherit='stock.move.operation.link'
    
    @api.model
    def create(self,vals):
    	res=super(StockMoveOperationLink,self).create(vals)
    	return res



