$(document).ready(function () {
    $( ".toggle_leftmenu").click(function() {
    	$(".oe_leftbar").slideToggle();
    	
    });
               
});
