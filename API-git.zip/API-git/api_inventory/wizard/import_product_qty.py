# -*- coding: utf-8 -*-
# copyright reserved

from openerp import models, fields, api,_
from openerp import tools
import math
from datetime import datetime
from datetime import datetime, date, time, timedelta
from openerp.exceptions import UserError
import sys
import logging
_logger = logging.getLogger(__name__)


class StockLocation(models.Model):
    _inherit = 'stock.location'
    
    @api.multi
    def importProduct(self):
        order_form = self.env.ref('api_inventory.product_store_import_data', False)
        context=self._context.copy()
        context.update({'default_location':self.id})
        return {
            'name':'Import Product data',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'product.store.data.import',
            'views': [(order_form.id, 'form')],
            'view_id': order_form.id,
            'context':context,
            'target': 'new',
         }

class StockProductDataImportWizard(models.TransientModel):
    """This wizard is used to Import product quantity and update in store  """   
    _name = 'product.store.data.import'
    
    name=fields.Char('File name')
    new_upload=fields.Binary('Upload File',attachment=True)
    location = fields.Many2one('stock.location','Location')
    region = fields.Many2one('stock.location.view','Storage Name')
    import_status = fields.Selection([('draft','Draft'),('error','Error'),('done','Done')],string='Import')
    
    @api.multi
    def import_data(self):
    	import base64
    	self.env.cr.execute("select store_fname from ir_attachment where res_model='product.store.data.import' and res_id="+str(self.id))
    	path=self.env.cr.fetchone()
    	
    	file_path='~/.local/share/Odoo/filestore/'+str(self.env.cr.dbname)+'/'+str(path[0])
    	
    	FILENAME = "/home/sagar/"+str(self.name)
    	with open(FILENAME, "wb") as f:
            text = self.new_upload
            f.write(base64.b64decode(text))
            
    	import xlrd
    	import xlwt
	book = xlrd.open_workbook(FILENAME)
	max_nb_row=book.sheet_by_index(1).nrows
	f_row=[]
	workbook = xlwt.Workbook(encoding = 'ascii')
	worksheet1 = workbook.add_sheet('ITEM CODE')
	worksheet1.write(0, 1, 'ITEM CODE')
	worksheet1.write(0, 2, 'Error')
	worksheet2 = workbook.add_sheet('Product')
	worksheet2.write(0, 1, 'ITEM CODE')
	worksheet2.write(0, 2, 'Error')
	worksheet3 = workbook.add_sheet('STORE')
	worksheet3.write(0, 1, 'STORE NAME')
	worksheet3.write(0, 2, 'Error')
	worksheet4 = workbook.add_sheet('Packaging')
	worksheet4.write(0, 1, 'ITEM CODE')
	worksheet4.write(0, 2, 'Primary pkg')
	worksheet4.write(0, 3, 'Secondary pkg')
	worksheet5 = workbook.add_sheet('Primary Qty')
	worksheet5.write(0, 1, 'ITEM CODE')
	worksheet5.write(0, 2, 'Qty in system ')
	worksheet5.write(0, 3, 'qty in file')
	worksheet6 = workbook.add_sheet('Secondary Qty')
	worksheet6.write(0, 1, 'ITEM CODE')
	worksheet6.write(0, 2, 'qty in system')
	worksheet6.write(0, 3, 'qty in file')
	count1=count2=count3=count4=count5=count6=1
	flag=False
	for row1 in range(max_nb_row) :
		if row1 != 0:
			data1=book.sheet_by_index(1).row_values(row1)
			product_id=False
			if data1[4]:
				try :
					if not float(data1[4]):
						flag=True
						worksheet1.write(count1, 1, label =str(int(data1[4])))
						worksheet1.write(count1, 2, label ='Code is not Proper')
						#raise UserError("Product Number"+str(int(data1[4]))+"is not Proper")
						count1 +=1
					product_id=self.env['product.product'].search([('default_code','=',str(int(data1[4])))])
					if not product_id:
						flag=True
						worksheet2.write(count2, 1, label =str(int(data1[4])))
						worksheet2.write(count2, 2, label ='Product Not Found')
						count2 +=1
					elif len(product_id)>1:
						flag=True
						worksheet2.write(count2, 1, label =str(int(data1[4])))
						worksheet2.write(count2, 2, label ='Multiple Product Found')
						count2 +=1
						continue
						#raise UserError("Product Number"+str(int(data1[4]))+"is not Found")
				except :
					worksheet1.write(count1, 1, label =str(data1[4]))
					worksheet1.write(count1, 2, label ='Error in code in searching')
					count1 +=1
					pass
			store_id=self.env['n.warehouse.placed.product'].search([('n_location','=',self.location.id),('n_location_view','=',self.region.id),('n_row','=',str(int(data1[0]))),('n_column','=',str(data1[1])),('n_depth','=',str(data1[2]))])
			if not store_id:
				flag=True
				worksheet3.write(count3, 1, label =str(int(data1[0]))+str(data1[1])+str(data1[2]))
				worksheet3.write(count3, 2, label ="Store Not Found")
				count3 +=1
			elif len(store_id)>1 :
				flag=True
				worksheet3.write(count3, 1, label =str(int(data1[0]))+str(data1[1])+str(data1[2]))
				worksheet3.write(count3, 2, label ="Multiple Store Found")
				count3 +=1
			elif store_id.state == 'full':
				flag=True
				worksheet3.write(count3, 1, label =str(int(data1[0]))+str(data1[1])+str(data1[2]))
				worksheet3.write(count3, 2, label ="Store is FULL")
				count3 +=1
			elif store_id.state == 'partial':
				if store_id.product_type == 'single':
					if store_id.pkg_capicity > (store_id.packages+data1[8]):
						flag=True
						worksheet3.write(count3, 1, label =str(int(data1[0]))+str(data1[1])+str(data1[2]))
						worksheet3.write(count3, 2, label ="Store is out of Capicity")
						count3 +=1
						
			elif store_id.state == 'maintenance':
				flag=True
				worksheet3.write(count3, 1, label =str(int(data1[0]))+str(data1[1])+str(data1[2]))
				worksheet3.write(count3, 2, label ="Store in maintainance")
				count3 +=1
			elif store_id.state == 'no_use':
				flag=True
				worksheet3.write(count3, 1, label =str(int(data1[0]))+str(data1[1])+str(data1[2]))
				worksheet3.write(count3, 2, label ="Store is Not in Use")
				count3 +=1
			primary=secondary=False
			if not product_id:
				continue
				
			for line in product_id.product_tmpl_id.packaging_ids:
				if line.pkgtype=='primary':
					if line.qty != int(data1[6]):
						flag=True
						worksheet5.write(count5, 1, label =str(product_id.default_code))
						worksheet5.write(count5, 2, label =str(line.qty))
						worksheet5.write(count5, 3, label =str(data1[6]))
						count5 +=1
						#raise UserError("Product "+str(int(data[4]))+"is packaging qty is not matching")	
					primary=line
							
				if line.pkgtype=='secondary':
					if line.qty < int(data1[8]):
						flag=True
						worksheet6.write(count6, 1, label =str(product_id.default_code))
						worksheet6.write(count6, 2, label =str(line.qty))
						worksheet6.write(count6, 3, label =str(data1[8]))
						count6 +=1
						# UserError("Product "+str(int(data[4]))+"is Pallet packaging qty is not matching")
					secondary=line
					
			if not primary or not secondary:	
				flag=True
				worksheet4.write(count4, 1, label =str(product_id.default_code))
				if not primary:
					worksheet4.write(count4, 2, label ="Primarypackaging not foud")
				if not secondary:
					worksheet4.write(count4, 3, label ="Seconadry packaging not foud")
				count4 +=1
				#raise UserError("Product Number"+str(int(data[4]))+"is packaging is not Found")	
	if flag:
		self.import_status = 'error'
		workbook.save('/home/sagar/Inventory_Import Error_Workbook{}.xls'.format(self.region.name))
		#return {'warning': {'title': "Invalid", 'message': "FIle Import ERROR \n Please Contact with Administrate and Open This File \n /home/aalmir/Excel_Workbook.xls in server System."}}	
		error_1="FIle Import ERROR \n Please Contact with Administrate and Open This File \n /home/aalmir/Excel_Workbook{}.xls in server System.".format(self.region.name)
		_logger.error(error_1)
		raise UserError(error_1)
		
	product_dic={}				
	for row in range(max_nb_row) :
		if row != 0:
			body=''
			data=book.sheet_by_index(1).row_values(row)
			product_id=unit=primary=secondary=False
			pkg_search=[]
			pkg_vals={}
			product_vals={}
			if data[4]:
				if not float(data[4]):
					raise UserError("Product Number"+str(int(data[4]))+"is not Proper")
				product_id=self.env['product.product'].search([('default_code','=',str(int(data[4])))])
				if not product_id:
					raise UserError("Product Number"+str(int(data[4]))+"is not Found")
				
			if data[6]:
				pkg_vals.update({'qty':data[6]})
			for line in product_id.product_tmpl_id.packaging_ids:
				if line.pkgtype=='primary':
					primary=line
							
				elif line.pkgtype=='secondary':
					secondary=line
					
			if not primary or not secondary:
				raise UserError("Product Number"+str(int(data[4]))+"is packaging is not Found")	
			if data[7]:
				unit=self.env['product.uom'].search([('name','=','Pcs')])
				pkg_vals.update({'uom_id':unit.id})
					
				if data[7].upper() in ('CTN'):
					pkg_type=self.env['product.uom'].search([('name','=','Catron')])
				if data[7].upper() in ('PALLET'):
					pkg_type=self.env['product.uom'].search([('name','=','Pallet')])
				if data[7].upper() in ('PCS'):
					pkg_type=self.env['product.uom'].search([('name','=','Pcs')])
				if data[7].upper() in ('BUNDLE'):
					pkg_type=self.env['product.uom'].search([('name','=','Bundle')])	
			
			store_id=self.env['n.warehouse.placed.product'].search([('n_location','=',self.location.id),('n_location_view','=',self.region.id),('n_row','=',str(int(data[0]))),('n_column','=',str(data[1])),('n_depth','=',str(data[2]))])
			if len(store_id)>1 or not store_id:
				raise UserError("Store selection ERROR")
			elif store_id.state in ('full','maintenance','no_use'):
				raise UserError("Store {}{}{} IS Full/Not in use".format(store_id.n_row,n_column,n_depth))
				
			elif  store_id.product_type == 'single':
				if not store_id.product_id:
					store_id.product_id=product_id.id
				elif store_id.product_id.id!= product_id.id:
					raise UserError("You can not store Two different products in single product type location \n Please Selection Multi store Location for two different product in same store")
					
				body+="<li>Product add : "+str(product_id.name)+" </li>"
				if primary and secondary:
					if store_id.pkg_capicity > (store_id.packages+int(data[9])):
						raise UserError("Storag is out of capicity")
					capacity=secondary.qty*store_id.max_qty
					store_id.pkg_capicity=capacity
					store_id.pkg_capicity_unit =secondary.unit_id.id
					body+="<li>Packaging Capicity : "+str(capacity)+" "+str(secondary.unit_id.name)+" </li>"
				store_id.packages += int(data[9])/primary.qty
				store_id.pkg_unit = secondary.unit_id.id
				body+="<li>No of Packages : "+str(data[9]/primary.qty)+" "+str(secondary.unit_id.name)+" </li>"
				store_id.total_quantity += int(data[9])
				store_id.total_qty_unit = unit.id
				body+="<li>Quantity Added : "+str(data[9])+" "+str(unit.name)+" </li>"
				store_id.Packaging_type = primary.id
				body+="<li>Packaging : "+str(primary.name)+" </li>"
				store_id.state = 'full' if store_id.pkg_capicity==store_id.packages else 'partial'
				
			elif  store_id.product_type == 'multi':	
				add_vals={'product_id':product_id.id}
				body+="<li>Product add : "+str(product_id.name)+" </li>"
				if primary and secondary:
					capacity=secondary.qty*store_id.max_qty
					add_vals.update({'pkg_capicity':capacity})
					add_vals.update({'pkg_capicity_unit':secondary.unit_id.id})
					body+="<li>Packag Capicity : "+str(capacity)+" "+str(secondary.unit_id.name)+" </li>"
				add_vals.update({'packages':data[9]/primary.qty})
				add_vals.update({'pkg_unit':secondary.unit_id.id})
				body+="<li>No of Packages :"+str(data[9]/primary.qty)+" "+str(secondary.unit_id.name)+" </li>"
				add_vals.update({'total_quantity':data[9]})
				add_vals.update({'total_qty_unit':unit.id})
				body+="<li>Quantity Added:"+str(data[9])+" "+str(unit.name)+" </li>"
				add_vals.update({'Packaging_type':primary.id})
				body+="<li>Packaging : "+str(primary.name)+" </li>"
				store_id.multi_product_ids=[(0,0,add_vals)]
				store_id.state = 'partial'
			else:
				raise UserError("Store Updation error")
				
			if data[8]:
				n_qty = int(data[9])
				for batct in range(int(math.ceil(data[8]))):
					a_qty= n_qty if n_qty < data[6] else data[6]
					n_qty += data[6]
					self.env['mrp.order.batch.number'].create({'product_id':product_id.id,
						 'approve_qty':a_qty,'product_qty':a_qty,'uom_id':unit.id,
						 'name':'ABC-data','store_id':store_id.id,'request_state':'done'})
			store_id.message_post(body)
			self.env['location.history'].create({'stock_location':store_id.id,
							'product_id':product_id.id,
							'qty':data[9],'n_type':'in','operation':'im'})
			
			if  product_dic.get(str(product_id.id)):
				product_dic[str(product_id.id)] += int(data[9]) 
			else:
				 product_dic.update({str(product_id.id):int(data[9])})
				 
	for line in product_dic:
		product_id=self.env['product.product'].search([('id','=',line)])
		quants=self.env['stock.quant'].search([('product_id','=',product_id.id),	
							('location_id','=',self.location.id)])
							
		avl_qty=sum([ q.qty for q in quants if q.qty>0 ])
		inventory_qty=self.env['stock.change.product.qty']
		inv_vals={'product_id':product_id.id,'product_tmpl_id': product_id.product_tmpl_id.id,
			  'location_id':self.location.id,'new_quantity':avl_qty+product_dic[line]}
		inv_qty_update=inventory_qty.create(inv_vals)
		inv_qty_update.change_product_qty()
	self.import_status = 'done'	
			
			
