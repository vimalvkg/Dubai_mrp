# -*- coding: utf-8 -*-
# copyright reserved

from openerp import models, fields, api,_
import math
from datetime import datetime
from datetime import datetime, date, time, timedelta
from openerp.exceptions import UserError
import sys
import logging
_logger = logging.getLogger(__name__)



class StockStoreLocationWizard(models.TransientModel):
    """This wizard is used to preset the free store location for a given
    lots and batches.  """
    
    _name = 'stock.store.location.wizard'

    picking = fields.Many2one('stock.picking', string='Picking')
    product_id = fields.Many2one('product.product', string='Product')
    back_order_id = fields.Many2one('stock.backorder.confirmation', string='Picking')
    immediate_tra = fields.Many2one('stock.immediate.transfer', string='Picking')
    locations = fields.One2many('stock.store.location.wizard.line','wizard_id','Store Locations')
    backorder = fields.Boolean('',default=False)
    no_of_batch=fields.Float('No of Batches', compute='total_batches')
    per_batch_qty=fields.Float('Each Batch Qty')
    hide_button=fields.Boolean('Hide create Batch Button ')
     
    @api.multi
    @api.depends('per_batch_qty')
    def total_batches(self):
        for record in self:
            if record.per_batch_qty:
               qty=sum(line.product_qty if line.product_qty else line.qty_done for line in record.picking.pack_operation_product_ids)
               record.no_of_batch=math.ceil(qty/record.per_batch_qty)
                  
    @api.multi
    def issue_incomingbatch(self):
        for record in self:
            if not record.per_batch_qty:
               raise UserError("Please Fill the Required Per Batch Qty. for Batch Numbers Issue.....")
            else:
               pr_no=record.picking.name
               b_list=[]
               body='<b>New Batch Numbers Issue For Incoming:</b>'
               body +='<ul><li> Incoming No. : '+str(record.picking.name) +'</li></ul>'
               body +='<ul><li> Issued By   : '+str(self.env.user.name) +'</li></ul>' 
               body +='<ul><li> Issued Time : '+str(datetime.now() + timedelta(hours=4))+'</li></ul>' 
               body +='<ul><li> Batch Numbers: '
               for line in record.picking.pack_operation_product_ids:
                   lot=self.env['stock.production.lot'].create({'product_id':line.product_id.id,
                                                        'picking_id':record.picking.id})
                   req=batch_qty=0.0
                   req=sum(line.product_qty if line.product_qty else line.qty_done for line in record.picking.pack_operation_product_ids)
                   for x in range(0, int(record.no_of_batch)): 
                       qty=0.0
                       if req >  record.per_batch_qty:
                          qty= record.per_batch_qty
                       else:
                          qty=req
                       code = self.env['ir.sequence'].next_by_code('mrp.order.batch.number') or 'New'
                       final_code= str(pr_no)+'-'+str(code)
                       batch=self.env['mrp.order.batch.number'].create({'name':final_code,
                                      'picking_id':record.picking.id,'lot_id':lot.id,
                                      'uom_id':line.product_uom_id.id,
                                      'product_qty':qty,'product_id':line.product_id.id,
                                      #'sale_id':record.production_id.sale_id.id if record.production_id.sale_id else False,
                                      #'sale_line_id':record.production_id.sale_line.id if record.production_id.sale_line else False,
                                      'logistic_state':'ready',})
                       req -=record.per_batch_qty
                       body +=str(batch.name)+','
                   record.hide_button=True
                   body +='</li></ul>' 
                   record.picking.message_post(body=body) 
                   return {
			'type': "ir.actions.do_nothing",
		    }

    @api.multi
    def process(self):
    	self.ensure_one()
    	if not self.locations:
    		raise UserError("Please Select Location")
	qty_check=total_check=0
	product_id=False
	
	for operation in self.picking.pack_operation_product_ids:
    	   		product_id= operation.product_id if operation.product_id else False
	    	   	qty_check += operation.qty_done if operation.qty_done else operation.product_qty
    	   	
	for line_check in self.locations:
   		if line_check.select_store and line_check.batch_ids:
    	   		for res in line_check.batch_ids:
		                total_check += res.convert_product_qty if res.convert_product_qty else res.product_qty
		                
        if qty_check != total_check:
		raise UserError("Selected batches Quantity  {} is not equal to opeartion Quantity  {} ".format(total_check,qty_check))	
			
    	for line in self.locations:
    	   #Sale_line_id =False
    	   mo_number=self.env['mrp.production'].search([('name','=',self.picking.origin)])
    	   po_number=self.env['purchase.order'].search([('name','=',self.picking.origin)])
	   print "llllllllllllllllllll",po_number,self.picking.origin
    	   if line.select_store and line.batch_ids:
    	   	batches_id=[]
    	   	body=''
    	   	if line.batch_ids==[]:
    	   		raise UserError("Please add Batches in store location {}/{}/{} ",format(line.locations.n_row,line.locations.n_shelf,line.locations.n_case))		
    	   	for rec in line.batch_ids:
    	   		if rec.id in batches_id:
				raise exceptions.Warning(_("Your batch {} appered in Multiple store locations",format(rec.name)))		
   			else:
   				batches_id.append(rec.id)
    	   	qty=total_qty=0
    	   	unit=False
    	   	for res in line.batch_ids:
                        qty = res.convert_product_qty if res.convert_product_qty else res.product_qty
                        total_qty += qty
			unit=res.qty_unit_id
			res.store_id = line.locations.id
    			store_data=self.env['picking.lot.store.location'].create({'picking_id':self.picking.id,
    							'store_id':line.locations.id,'quantity':qty,
    							'lot_number':res.lot_id.id,'batch_number':res.id,
    							'unit_id':res.qty_unit_id.id,'product_id':res.product_id.id})
			if res.sale_line_id:
    				res.logistic_state='reserved'
			else:
				res.logistic_state='stored'
			
		if line.locations.product_type == 'single':
			body+="<ul>New Quantity Added in Store</ul>"
			line.locations.product_id=product_id.id
			body+="<li>Product add : "+str(product_id.name)+" </li>"
			line.locations.pkg_capicity=self.picking.pallet_size
			line.locations.pkg_capicity_unit =self.picking.pallet_qty_unit.id
			body+="<li>Package Capicity : "+str(self.picking.pallet_size)+" "+str(self.picking.pallet_qty_unit.name)+" </li>"
			line.locations.packages = self.picking.packaging_count
			line.locations.pkg_unit = self.picking.pallet_qty_unit.id
			body+="<li>No of Packages : "+str(self.picking.pallet_size)+" "+str(self.picking.pallet_qty_unit.name)+" </li>"
			line.locations.total_quantity = total_qty 
			line.locations.total_qty_unit = unit.id if unit else False
			body+="<li>Quantity Added : "+str(qty)+" "+str(unit.name if unit else '')+" </li>"
			line.locations.Packaging_type = self.picking.packaging.id
			body+="<li>Packaging : "+str(self.picking.packaging.name)+" </li>"
			
		elif line.locations.product_type=='multi':
			body+="<ul>New Quantity Added in Store</ul>"
			store_vals={'product_id':product_id.id}
			body+="<li>Product add : "+str(product_id.name)+" </li>"
			store_vals.update({'pkg_capicity':self.picking.pallet_size})
			store_vals.update({'pkg_capicity_unit':self.picking.pallet_qty_unit.id})
			body+="<li>Package Capicity : "+str(self.picking.pallet_size)+" "+str(self.picking.pallet_qty_unit.name)+" </li>"
			store_vals.update({'packages': self.picking.packaging_count})
			store_vals.update({'pkg_unit': self.picking.pallet_qty_unit.id})
			body+="<li>No of Packages : "+str(self.picking.pallet_size)+" "+str(self.picking.pallet_qty_unit.name)+" </li>"
			store_vals.update({'total_quantity': total_qty}) 
			store_vals.update({'total_qty_unit': unit.id if unit else False})
			body+="<li>Quantity Added : "+str(qty)+" "+str(unit.name if unit else '')+" </li>"
			store_vals.update({'Packaging_type': self.picking.packaging.id})
			body+="<li>Packaging : "+str(self.picking.packaging.name)+" </li>"
			line.locations.multi_product_ids=[(0,0,store_vals)]
			
		line.locations.state = 'full'
		line.locations.message_post(body)
		line.locations.n_mo_number=mo_number.id if mo_number else False
		line.locations.n_po_number=po_number.id if po_number else False
		#if Sale_line_id:
		#	line.sale_reserve_ids=[(0,0,{'store_id':line.locations.id,'sale_line_id':Sale_line_id.id,
		#			    'sale_id':Sale_line_id.order_id.id,'product_qty':qty,'uom_id':unit.id if unit else False})]
		self.env['location.history'].create({'stock_location':line.locations.id,
							'product_id':product_id.id,
							'qty':total_qty,'n_type':'in',
							'operation':'mo' if mo_number else 'po' if po_number else False,
							'n_mo_number':mo_number.id if mo_number else False,
							'n_po_number':po_number.id if po_number else False,})
							
    	if self.back_order_id:
    		self.back_order_id._process(cancel_backorder=self.backorder)
    		self.picking.do_transfer()
	elif self.immediate_tra:
		self.picking.do_transfer()
	elif self.picking:
		self.picking.do_transfer()
		
    @api.multi
    def store_validate(self):
    	error_str=error_str_1=''
    	try:
		for rec in self:
			flag=flag_error=False
			for opr in rec.picking.pack_operation_product_ids:
				batch_qty=0.0
				for line in rec.locations:
					if line.select_store and line.product_id.id == opr.product_id.id:
						for batch in line.batch_ids:
							batch_qty += batch.convert_product_qty
							
				if opr.qty_done != batch_qty:
					flag_error= True
					error_str_1="Product:'{}' Dispatch qty :{} , Batch Qty :{} dispatch quantity\n".format(opr.product_id.name,opr.qty_done,batch_qty)
			if flag_error:
				error_str="You select more quantity batches Than dispatch quantity\n"+error_str_1
				raise
			store_history=[]
			for op in rec.picking.pack_operation_product_ids:
				qty=op.qty_done	
				for line in rec.locations:				
					if line.select_store and line.product_id.id == opr.product_id.id:
						for loc in line.locations_ids:
							st_qty=0.0
							for btch in line.batch_ids:
								st_qty += btch.convert_product_qty
								btch.store_id=False
								batch.logistic_state='dispatch'
								store_history.append((6,0,{
									'picking_id':op.picking_id.id,
									'store_id':loc.id,
									'product_id':line.product_id.id,
									'quantity':btch.convert_product_qty,
									'unit_id':btch.qty_unit_id.id,
									'lot_number':btch.lot_id.id,
									'batch_number':btch.id,}))
							n_qty=st_qty
							if loc.product_type=='single':	
								n_qty=loc.total_quantity
								loc.total_quantity -= st_qty
								st_qty -=  n_qty
								if loc.total_quantity <=0:
									loc.state = 'empty'
									loc.product_id = False
									loc.qty_unit = False
									loc.pkg_capicity = False
									loc.pkg_capicity_unit = False
									loc.packages = False
									loc.pkg_unit = False
									loc.Packaging_type = False			
									flag=True

							elif loc.product_type=='multi':
								for pro in line.multi_product_ids:
									if  pro.product_id.id==line.product_id.id:
										n_qty=pro.total_quantity
										pro.total_quantity -= st_qty
										st_qty -=  n_qty
										if pro.total_quantity <=0:
											pro.unlink()
										if st_qty <=0:
											break

							self.env['location.history'].create({
									'stock_location':loc.id,
									'product_id':line.product_id.id,
									'qty':n_qty,'n_type':'out',
									'n_do_number':op.picking_id.id,
									'operation':'do'
									})
									
			if store_history:
				op.picking_id.store_ids=store_history
    	except Exception as err:
		if error_str:
			_logger.error(error_str)
   			raise UserError(error_str)
		else:
    			exc_type, exc_obj, exc_tb = sys.exc_info()
	    		_logger.error("API-EXCEPTION..Exception in Dispatchig of product {} {}".format(err,exc_tb.tb_lineno))
	    		raise UserError("API-EXCEPTION..Exception in Dispatchig of product {} {}".format(err,exc_tb.tb_lineno))			
    	return self.picking.action_first_validation_data()
    	
class StockStoreLocationWizardLine(models.TransientModel):
    """This is a temporary table to get and store the Lot in store location 
    """
    _name = 'stock.store.location.wizard.line'

    select_store = fields.Boolean('Store Select')
    wizard_id = fields.Many2one('stock.store.location.wizard', string='Wizard')
    locations = fields.Many2one('n.warehouse.placed.product','Store Location')
    max_qty = fields.Float('Storage Capacity')
    qty_unit = fields.Many2one('product.uom','Unit')
    lot_ids = fields.Many2many('stock.production.lot','lot_store_inventory_wizard','lot_id','wizard_id','Transfer No')
    batch_ids = fields.Many2many('mrp.order.batch.number','batch_store_inventory_wizard','batch_id','wizard_id','Batch No.')
    locations_ids = fields.Many2many('n.warehouse.placed.product','warehouse_store_inventory_wizard_rel',
    				     'wiz_id','loc_id','Store Names')
    product_id = fields.Many2one('product.product', string='Product')
    #n_free_qty = fields.Float('Free Storage')
    #quantity = fields.Float('Store Quantity')
    
    @api.onchange('lot_ids')
    def lot_onchange(self):
    	for res in self:
    		ids=res.lot_ids._ids
    		search_id = self.env['mrp.order.batch.number'].search([('lot_id','in',ids)])
    		if search_id :
    			res.batch_ids = [(4,i) for i in search_id._ids]
		if not res.lot_ids:
			res.batch_ids = []
			
    @api.onchange('locations_ids')
    def locations_onchange(self):
    	for res in self:
    		ids=res.locations_ids._ids
    		search_id = self.env['mrp.order.batch.number'].search([('store_id','in',ids)])
    		if search_id :
    			res.batch_ids = [(4,i) for i in search_id._ids]
		if not res.locations_ids:
			res.batch_ids = []
   
class stock_immediate_transfer(models.TransientModel):
    _inherit = 'stock.immediate.transfer'

    @api.multi
    def process(self):
    	self.ensure_one()
        if self.pick_id.picking_type_id.code=='internal' and self.pick_id.picking_type_id.default_location_src_id.pre_ck:  
        	context=self._context.copy()      
		data=[]
		free_ids=self.env['n.warehouse.placed.product'].search([('product_id','=',False),('multi_product_ids','=',False),('state','=','empty')])
		wizard_id=self.env['stock.store.location.wizard'].search([('picking','=',self.pick_id.id)])
		wizard_id.unlink()
		purchase=self.env['purchase.order'].search([('name','=',self.pick_id.origin)],limit=1)
		data=self.env['stock.backorder.confirmation']._get_bacthes(free_ids,self.pick_id)
                context.update({'incoming':True if purchase else False, 
                                'location':True if data else False})
		vals={'immediate_tra':self.id,'picking':self.pick_id.id,'locations':data}
		res_id=self.env['stock.store.location.wizard'].create(vals)
		form_id = self.env.ref('api_inventory.store_locations_form_view_wizard')
		return {
			'name' :'Select Store Location',
			'type': 'ir.actions.act_window',
			'view_type': 'form',
			'view_mode': 'form',
			'res_model': 'stock.store.location.wizard',
			'views': [(form_id.id, 'form')],
			'view_id': form_id.id,
			'target': 'new',
                        'context':context,
			'res_id':res_id.id,
		    }
        
        # If still in draft => confirm and assign
        if self.pick_id.state == 'draft':
            self.pick_id.action_confirm()
            if self.pick_id.state != 'assigned':
                self.pick_id.action_assign()
                if self.pick_id.state != 'assigned':
                    raise UserError(_("Could not reserve all requested products. Please use the \'Mark as Todo\' button to handle the reservation manually."))
        for pack in self.pick_id.pack_operation_ids:
            if pack.product_qty > 0:
                pack.write({'qty_done': pack.product_qty})
            else:
                pack.unlink()
        self.pick_id.do_transfer()

    
class stock_backorder_confirmation(models.TransientModel):
    _inherit = 'stock.backorder.confirmation'
    
    @api.multi
    def process(self):
        self.ensure_one()
        if self.pick_id.picking_type_id.code=='internal' and self.pick_id.picking_type_id.default_location_src_id.pre_ck:
		free_ids=self.env['n.warehouse.placed.product'].search([('product_id','=',False),('multi_product_ids','=',False),('state','=','empty')])
		wizard_id=self.env['stock.store.location.wizard'].search([('picking','=',self.pick_id.id)])
		wizard_id.unlink()
		
		data=self._get_bacthes(free_ids,self.pick_id)
		vals={'back_order_id':self.id,'picking':self.pick_id.id,'locations':data}
		res_id=self.env['stock.store.location.wizard'].create(vals)
		form_id = self.env.ref('api_inventory.store_locations_form_view_wizard')
		return {
			'name' :'Select Store Location',
			'type': 'ir.actions.act_window',
			'view_type': 'form',
			'view_mode': 'form',
			'res_model': 'stock.store.location.wizard',
			'views': [(form_id.id, 'form')],
			'view_id': form_id.id,
			'target': 'new',
			'res_id':res_id.id,
			#'flags': {'form': {'action_buttons': False, 'options': {'mode': 'edit'}}}
		    }
        self._process()

    @api.multi
    def process_cancel_backorder(self):
        self.ensure_one()
        if self.pick_id.picking_type_id.code=='internal' and self.pick_id.picking_type_id.default_location_src_id.pre_ck:
		data=[]
		free_ids=self.env['n.warehouse.placed.product'].search([('product_id','=',False),('multi_product_ids','=',False),('state','=','empty')])
		wizard_id=self.env['stock.store.location.wizard'].search([('picking','=',self.pick_id.id)])
		wizard_id.unlink()
		
		data=self._get_bacthes(free_ids,self.pick_id)
		vals={'back_order_id':self.id,'picking':self.pick_id.id,'locations':data,'backorder':True,}
		res_id=self.env['stock.store.location.wizard'].create(vals)
		form_id = self.env.ref('api_inventory.store_locations_form_view_wizard')
		return {
			'name' :'Select Store Location',
			'type': 'ir.actions.act_window',
			'view_type': 'form',
			'view_mode': 'form',
			'res_model': 'stock.store.location.wizard',
			'views': [(form_id.id, 'form')],
			'view_id': form_id.id,
			'target': 'new',
			'res_id':res_id.id,
			#'flags': {'form': {'action_buttons': True, 'options': {'mode': 'edit'}}}
		    }
        self._process(cancel_backorder=True)

    @api.model
    def _get_bacthes(self,free_ids,pick_id):
    	''' This method is used to get batches for store location in wizard on validation in move to store picking '''
    	data=[]
    	completed_ids=[]
    	mrp_id=self.env['mrp.production'].search([('name','=',pick_id.origin)],limit=1)
    	pallet_id=self.env['product.uom'].search([('name','=ilike','Pallet')],limit=1)
    	c=1
    	
    	for pkg in mrp_id.product_id.packaging_ids:
		if pkg.pkgtype == 'secondary':
			pckg_qty = pkg.qty
			break
					
	for line in free_ids:
		batches=[]
		lots=[]
		pckg_qty = 0
		btch=0
		if mrp_id:
			bacthes_ids=self.env['mrp.order.batch.number'].search([('production_id','=',mrp_id.id),('lot_id','!=',False),('approve_qty','>',0),('store_id','=',False),('product_qty','>',0),('id','not in',tuple(completed_ids))])
			for batch in bacthes_ids:
				batches.append(batch.id)
				completed_ids.append(batch.id)
				lots.append(batch.lot_id.id)
				#qty+=batch.approve_qty
				btch +=1
				if btch >= pckg_qty:
					break
					
		batches=list(set(batches))
		lots=list(set(lots))
		if c<=pick_id.total_no_pallets:
			data.append((0,0,{'locations':line.id,'max_qty':line.max_qty,'qty_unit':pallet_id.id,
			'select_store':True,'lot_ids':[(6,0,lots)],'batch_ids':[(6,0,batches)]}))
		c +=1
	return data
    	
