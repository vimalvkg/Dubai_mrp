# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
#CH03 add on_change to change base currency and converted currency

from openerp import api, fields, models, _
from openerp import fields
import openerp.addons.decimal_precision as dp
from openerp.exceptions import UserError
from datetime import datetime
import re
from dateutil.relativedelta import relativedelta

class productTemplate(models.Model):
	_inherit = "product.template"

	@api.multi
	def open_inventory_location(self):
		order_tree = self.env.ref('api_inventory.product_stock_location_tree', False)
		order_form = self.env.ref('api_inventory.product_stock_location_from', False)
		product_id = self.env['product.product'].search([('product_tmpl_id','=',self.id)])
		product_id = [p.id for p in product_id]
		return {
		    'name':'Inventory Location Product',
		    'type': 'ir.actions.act_window',
		    'view_type': 'form',
		    'view_mode': 'tree',
		    'res_model': 'n.warehouse.placed.product',
		    'views': [(order_tree.id, 'tree'),(order_form.id, 'form')],
		    'view_id': order_form.id,
		    'domain':['|',('multi_product_ids.product_id','in',product_id),('product_id','in',product_id)],
		    'target': 'current',
		 }
		 

class productProduct(models.Model):
	_inherit = "product.product"

	@api.multi
	def open_inventory_location(self):
		return self.product_tmpl_id.open_inventory_location()

	@api.model
	def name_search(self,name, args=None, operator='ilike', limit=100):
		''' function to show product from multi store product location'''
		if self._context.get('multi_loc'):
			if self._context.get('store_id'):
				store_ids=self.env['store.multi.product.data'].search([('store_id','=',self._context.get('store_id'))])
		        	return [(rec.product_id.id,rec.product_id.name) for rec in store_ids]
			return []
	    	return super(productProduct,self).name_search(name, args, operator=operator, limit=limit)
		
	# inherite method to restrict quantity to show only  in store location
    	@api.v7
	def _get_domain_locations(self,cr, uid, ids, context=None):
		'''
		Parses the context and returns a list of location_ids based on it.
		It will return all stock locations when no parameters are given
		Possible parameters are shop, warehouse, location, force_company, compute_child
		'''
		context = context or {}

		location_obj = self.pool.get('stock.location')
		warehouse_obj = self.pool.get('stock.warehouse')

		location_ids = []
		if context.get('location', False):
		    if isinstance(context['location'], (int, long)):
			location_ids = [context['location']]
		    elif isinstance(context['location'], basestring):
			domain = [('complete_name','ilike',context['location'])]
			if context.get('force_company', False):
			    domain += [('company_id', '=', context['force_company'])]
			location_ids = location_obj.search(cr, uid, domain, context=context)
		    else:
			location_ids = context['location']
		else:
		    if context.get('warehouse', False):
			if isinstance(context['warehouse'], (int, long)):
			    wids = [context['warehouse']]
			elif isinstance(context['warehouse'], basestring):
			    domain = [('name', 'ilike', context['warehouse'])]
			    if context.get('force_company', False):
				domain += [('company_id', '=', context['force_company'])]
			    wids = warehouse_obj.search(cr, uid, domain, context=context)
			else:
			    wids = context['warehouse']
		    else:
			wids = warehouse_obj.search(cr, uid, [], context=context)

		    for w in warehouse_obj.browse(cr, uid, wids, context=context):
			location_ids.append(w.view_location_id.id)


		operator = context.get('compute_child', True) and 'child_of' or 'in'
		domain = context.get('force_company', False) and ['&', ('company_id', '=', context['force_company'])] or []
		locations = location_obj.browse(cr, uid, location_ids, context=context)
		loc_id=self.pool.get('stock.location').search(cr,uid,[('actual_location','=',True)])
		if operator == "child_of" and locations and locations[0].parent_left != 0:
		    loc_domain = []
		    dest_loc_domain = []
		    for loc in locations:
			if loc_domain:
			    loc_domain = ['|'] + loc_domain  + ['&', ('location_id.parent_left', '>=', loc.parent_left), ('location_id.parent_left', '<', loc.parent_right)]
			    dest_loc_domain = ['|'] + dest_loc_domain + ['&', ('location_dest_id.parent_left', '>=', loc.parent_left), ('location_dest_id.parent_left', '<', loc.parent_right)]
			else:
			    loc_domain += ['&', ('location_id.parent_left', '>=', loc.parent_left), ('location_id.parent_left', '<', loc.parent_right)]
			    dest_loc_domain += ['&', ('location_dest_id.parent_left', '>=', loc.parent_left), ('location_dest_id.parent_left', '<', loc.parent_right)]
		    
		    return (
			domain + [('location_id','in',loc_id)],
			domain + ['&'] + dest_loc_domain + ['!'] + loc_domain,
			domain + ['&'] + loc_domain + ['!'] + dest_loc_domain
		    )
		else:
		    return (
			#domain + [('location_id', operator, location_ids)], # coment it to get location
			domain + [('location_id','in',loc_id)],
			domain + ['&', ('location_dest_id', operator, location_ids), '!', ('location_id', operator, location_ids)],
			domain + ['&', ('location_id', operator, location_ids), '!', ('location_dest_id', operator, location_ids)]
		    )

class productPackging(models.Model):
    _inherit = 'product.packaging'
    
    @api.model
    def name_search(self,name, args=None, operator='ilike', limit=100):
	if self._context.get('primary'):
		if self._context.get('product_id'):
			product_id=self.env['product.product'].search([('id','=',self._context.get('product_id'))])
			packg=self.search([('pkgtype','=','primary'),('product_tmpl_id','=',product_id.product_tmpl_id.id)])
                	return [(rec.id,rec.name) for rec in packg]
        	return []
	if self._context.get('secondary'):
		if self._context.get('product_id') and self._context.get('primary_packaging'):
			print "---",self._context.get('primary_packaging')
			primary_packaging = self.search([('id','=',self._context.get('primary_packaging'))])
			product_id=self.env['product.product'].search([('id','=',self._context.get('product_id'))])
			packg=self.search([('pkgtype','=','secondary'),('product_tmpl_id','=',product_id.product_tmpl_id.id)])
                	return [(rec.id,rec.name) for rec in packg if primary_packaging.uom_id.id ==rec.unit_id.id ]
        	return []
    	return super(productPackging,self).name_search(name, args, operator=operator, limit=limit)

class ProductUom(models.Model):
    _inherit = "product.uom"
    
    @api.model
    def name_search(self,name, args=None, operator='ilike',limit=100):
	if self._context.get('release'):
		if self._context.get('release_product'):
			product_id=self.env['product.product'].search([('id','=',self._context.get('release_product'))])
			packg = self.env['product.packaging'].search([('product_tmpl_id','=',product_id.product_tmpl_id.id)])
			if packg:
				return [(rec.unit_id.id,rec.unit_id.name) for rec in packg]
		return []
		
	if self._context.get('store_unit'):
		units = self.search([('unit_type.string','=','store')])
		args=[('id','in',list(units._ids))]
    	return super(ProductUom,self).name_search(name, args, operator=operator,limit=limit)
		    
class stockproductionlot(models.Model):
	_inherit = 'stock.production.lot'	
	store_id = fields.Many2one('n.warehouse.placed.product', 'Store Location')
        picking_id=fields.Many2one('stock.picking')

    	@api.model
    	def name_search(self, name, args=None, operator='ilike',limit=100):
    		print "/*//*//-------------",self._context.get('picking_origin'),
        	if self._context.get('picking_origin'):
        		picking=self.env['stock.picking'].search([('id','=',self._context.get('picking_origin'))],limit=1)
                        if self._context.get('batch_no'):
                           lot_ids=self.search([('picking_id','=',picking.id)])
                           return [(rec.id,rec.name) for rec in lot_ids]
        		lots=[]
        		if self._context.get('lot_id'):
        			lots=self._context.get('lot_id')[0][2] if self._context.get('lot_id')[0] else []
                	mo_ids=self.env['mrp.production'].search([('name','=',picking.origin)],limit=1)
                	batches=self.env['mrp.order.batch.number'].search([('store_id','=',False),('approve_qty','>',0),('production_id','=',mo_ids.id)])
                	lot_id=self.search([('production_id','=',mo_ids.id)])
                	if lot_id:
                		args= [('id','in',[rec.lot_id.id for rec in batches if rec.lot_id.id not in lots])]
                	else:	
        			return []
        	return super(stockproductionlot,self).name_search(name, args, operator=operator,limit=limit)
	
class MrpWorkorderBatchNo(models.Model):
	_inherit='mrp.order.batch.number'

    	store_id = fields.Many2one('n.warehouse.placed.product', 'Store Location')
	picking_id=fields.Many2one('stock.picking')
	
    	@api.model
    	def name_search(self, name, args=None, operator='ilike',limit=100):
        	if self._context.get('store_wizard'):
        		if self._context.get('lot_id'):
        			batch=[]
        			if self._context.get('batch'):
	        			batch=self._context.get('batch')[0][2] if self._context.get('batch')[0] else []
                		material=self.search([('store_id','=',False),('approve_qty','>',0),('logistic_state','=','ready'),('lot_id','in',self._context.get('lot_id')[0][2])])
                		print ",,,,,,,,,,,,,,",material,self._context.get('lot_id')[0][2]
				wizard=self.env['stock.store.location.wizard'].search([('id','=',self._context.get('wizard_id'))])
                		return [(rec.id,rec.name) for rec in material if rec.id not in batch]
        		return []
        		
        	if self._context.get('outgoing_wizard'):
        		if self._context.get('store_id'):
        			batch=[]
        			if self._context.get('batch'):
	        			batch=self._context.get('batch')[0][2] if self._context.get('batch')[0] else []
                		material=self.search([('logistic_state','=','reserved'),('store_id','in',self._context.get('store_id')[0][2])])
				wizard=self.env['stock.store.location.wizard'].search([('id','=',self._context.get('wizard_id'))])
                		return [(rec.id,rec.name) for rec in material if rec.id not in batch]
        		return []
        		
		if self._context.get('transfer_wizard'):
        		if self._context.get('store_id'):
        			product_id=False
				if self._context.get('multi_product_id'):
					product_id=self.env['store.multi.product.data'].search([('id','=',self._context.get('multi_product_id'))]).product_id.id
				else:
					product_id= self._context.get('product_id')
			
				if product_id:
					batchs=[]
					if self._context.get('batch_id'):
						batchs=self._context.get('batch_id')[0][2] if self._context.get('batch_id')[0] else []
		        		search_ids=self.search([('logistic_state','in',('reserved','stored','r_t_dispatch')),('product_id','=',product_id),('store_id','=',self._context.get('store_id'))])
                			return [(rec.id,rec.name) for rec in search_ids if rec.id not in batchs]
        			return []
        		return []
        
        	return super(MrpWorkorderBatchNo,self).name_search(name, args, operator=operator,limit=limit)
    		
