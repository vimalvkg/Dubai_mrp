# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from openerp import api, fields, models, _
from openerp.tools.translate import _
from openerp.exceptions import UserError, ValidationError
from openerp import fields
import openerp.addons.decimal_precision as dp
from datetime import datetime
import re
from dateutil.relativedelta import relativedelta


class StockWarehouseMain(models.Model):
	_name = "n.warehouse.placed.product"
	_inherit = 'mail.thread'
	_order = "state,n_location_view,n_row,n_column,n_depth"
	
	@api.multi
	@api.depends('pkg_capicity','packages')
	def _get_free_qty(self):
		for rec in self:
			rec.n_free_qty=rec.pkg_capicity - rec.packages
				
	n_mo_number = fields.Many2one("mrp.production","MO Number")
    	n_po_number = fields.Many2one("purchase.order","PO Number")
    	#n_do_number = fields.Many2one("stock.picking","DO Number")
    	#n_qc_number = fields.Many2one("stock.picking","QC Number")
    	
	n_warehouse = fields.Many2one('stock.warehouse','Warehouse')
	n_location = fields.Many2one('stock.location','Location')
	n_location_view = fields.Many2one('stock.location.view','Storage Name',ondelete='cascade')
	n_row = fields.Char('Row Name')
	n_column =fields.Char('Column Name')
	n_depth =fields.Char('Depth Name')
	
	product_type = fields.Selection([('single','Single Product'),('multi','Multi Product')],'Product Type')
	product_id = fields.Many2one('product.product', string="Product")
	multi_product_ids =fields.One2many('store.multi.product.data','store_id','Product Details')

	state= fields.Selection([('empty','Empty'),('partial','Partial'),('full','FULL'),('maintenance','In Maintenance'),('no_use','Not in Use')],default='empty')
	label_status = fields.Selection([('done','Done'),('warehouse','Warehouse'),
					 ('location','Location'),('row','Row'),
					 ('column','Column'),('depth','Depth'),('less_qty','Less Qty')],default='done')
	max_qty = fields.Float('Storage Capacity',default=0.0)
	qty_unit = fields.Many2one("product.uom",'Unit')
	
	pkg_capicity = fields.Float('Packages Capacity',default=0.0,help="maximum capacity of storage in packets, Caucluation based on product packaging")
	pkg_capicity_unit = fields.Many2one("product.uom",'Unit')
	n_free_qty = fields.Float('Free Quantity',compute="_get_free_qty")
	
	Packaging_type = fields.Many2one('product.packaging' ,string="Packaging",copy=True)
	packages = fields.Float('No of Packages',default=0.0,help="Total No. of packets currently in Storage")
	pkg_unit = fields.Many2one("product.uom",'Unit')
	
	total_quantity = fields.Float('Total Store Quantity',default=0.0, help="total quantity in product units")
	total_qty_unit = fields.Many2one("product.uom",'Unit')
	#lot_numbers = fields.One2many('stock.production.lot','store_id', string="Lot Numbers")
	# API code
	#batches_ids = fields.One2many('picking.lot.store.location','store_id','Store Location')
	store_batches_ids = fields.One2many('mrp.order.batch.number','store_id','Store Location')
	
	@api.multi
	def name_get(self):
	    result = []
	    for record in self:
		name = str(record.n_location.name)+'-'+str(record.n_location_view.name) +'/'+ str(record.n_row) +'/'+ str(record.n_column) +'/'+ str(record.n_depth)
		result.append((record.id, name))
	    return result
    
    	@api.multi
    	def open_stock_history(self):
    		for rec in self:
    			order_tree = self.env.ref('api_inventory.stock_location_history_action_tree', False)
			return {
			    'name':'History Location Product',
			    'type': 'ir.actions.act_window',
			    'view_type': 'form',
			    'view_mode': 'tree',
			    'res_model': 'location.history',
			    'views': [(order_tree.id, 'tree')],
			    'view_id': order_tree.id,
			    'domain':[('stock_location','=',rec.id)],
			    'target': 'new',
			 }

    	@api.multi
    	def stock_operation(self):
    	   for rec in self:
    		order_form=name=''
    		context = self._context.copy()
		context.update({'default_product_id':rec.product_id.id if rec.product_id else False,
				'default_stock_location':rec.id,'default_location_id':rec.n_location.id})
	    	if self._context.get('add_stock'):
    			order_form = self.env.ref('api_inventory.add_stock_location_operation_form', False)
    			name='Add Quantity In Store'
    			context.update({'default_storage':0})
    			
	    	if self._context.get('release_stock'):
    			order_form = self.env.ref('api_inventory.remove_stock_location_operation_form', False)
    			name='Remove Quantity From Store'
    			print "kkkkkkkkkkkk",rec.total_quantity
    			context.update({'default_qty':rec.total_quantity})
    			
	    	if self._context.get('transfer_stock'):
    			order_form = self.env.ref('api_inventory.transfer_stock_location_operation_form', False)
    			name='Transfer Quantity In Store To Store'
    			#context.update({'default_qty':rec.n_qty})
    			
		if self._context.get('update_stock'):
    			order_form = self.env.ref('api_inventory.update_stock_location_operation_form', False)
    			name='Update Quantity In Store'
    		if name and order_form:	
			if rec.product_type == 'multi':
				product_ids=[]
				context.update({'multi_product_operation':True})
				
			return {
			    'name':name,
			    'type': 'ir.actions.act_window',
			    'view_type': 'form',
			    'view_mode': 'form',
			    'res_model': 'location.stock.operation',
			    'views': [(order_form.id, 'form')],
			    'view_id': order_form.id,
			    'context':context,
			    'target': 'new',
			 }
			 
	#@api.model
	#def create(self,vals):
	#	if vals.get('n_qty') and vals.get('max_qty'):
	#		if vals.get('n_qty') >= vals.get('max_qty'):
	#			vals.update({'state':'full'})
	#		else:
	#			vals.update({'state':'partial'})
	#	return super(StockWarehouseMain,self).create(vals)

	@api.multi
	def change_storage_capicity(self):
    		context = self._context.copy()
    		unit=self.env['product.uom'].search([('name','=ilike','pallet')],limit=1)
    		packages = (self.pkg_capicity if self.pkg_capicity else 1) / (self.max_qty if self.max_qty else 1)
		context.update({'default_previous_storage_capicity':self.max_qty,
				'default_pre_capicity_unit':unit.id,
				'default_used_storage':float(self.packages)/packages,
				'default_stock_location':self.id,
				'default_new_capicity_unit':unit.id,
				'default_used_unit':unit.id})
		order_form = self.env.ref('api_inventory.update_storage_capicity_operation_form', False)
		return {
			    'name':"Update Storage Capicity",
			    'type': 'ir.actions.act_window',
			    'view_type': 'form',
			    'view_mode': 'form',
			    'res_model': 'location.stock.operation',
			    'views': [(order_form.id, 'form')],
			    'view_id': order_form.id,
			    'context':context,
			    'target': 'new',
			 }

	@api.model
    	def name_search(self, name, args=None, operator='ilike',limit=100):
    		# used in move to location validation wizard
		if self._context.get('outgoing_wizard'):
			args=[]
        		if self._context.get('product_id'):
        			store=[]
        			if self._context.get('store_id'):
	        			store=self._context.get('store_id')[0][2] if self._context.get('store_id')[0] else []
				wizard=self.env['stock.store.location.wizard'].search([('id','=',self._context.get('wizard_id'))])
				mrp_batches=self.env['mrp.order.batch.number'].search([('product_id','=',self._context.get('product_id')),('store_id','!=',False),('sale_id.name','=',str(wizard.picking.origin))])
				store_ids=list(set([rec.store_id.id for rec in mrp_batches if rec.store_id.id not in store]))
				args=[('id','in',store_ids)]
                		
		# used in transfer to location wizard in store location view
		if self._context.get('operation_store'):
			args=[]
			product_id=False
			if self._context.get('multi_product_id'):
				product_id=self.env['store.multi.product.data'].search([('id','=',self._context.get('multi_product_id'))]).product_id.id
			else:
				product_id= self._context.get('product_id')
			
			if product_id:
        			if self._context.get('store_id'):
                			store = self.search([('state','=','empty')])
                			store += self.search([('id','!=',self._context.get('store_id')),('product_id','=',product_id)])
                			return [(rec.id,str(rec.n_location.name)+'-'+str(rec.n_location_view.name) +'/'+ str(rec.n_row) +'/'+ str(rec.n_column) +'/'+ str(rec.n_depth)) for rec in store ]
        			return []
        		return []
        	return super(StockWarehouseMain,self).name_search(name, args, operator=operator,limit=limit)	

	@api.multi
	def operation_on_store(self):
		'''Store Available opeartion like "maintenace","not in use" '''
		if self.state == 'empty' or self._context.get('in_use'):
			if self.product_id or self.multi_product_ids:
				raise Usererror('Please make Empty location to perform operation')
			if self._context.get('maintenance'):
				self.state = 'maintenance'
			elif self._context.get('not_in_use'):
				self.state = 'no_use'
			elif self._context.get('in_use'):
				self.state = 'empty' 
			else:
				raise Userror('OPeration is not performerd.')
		else:
			raise Usererror('Please make Empty location to perform operation')
			
        	
class locationHistory(models.Model):
	_name = "location.history"
	
	stock_location = fields.Many2one('n.warehouse.placed.product','Stock Location')
	product_id = fields.Many2one('product.product', string="Product")
	qty = fields.Float('Quantity')
	operation_name= fields.Char('Operation')
	operation = fields.Selection([('im','Import'),('mo','Manufacture'),('po','Purchase'),('do','Delivery'),('transfer','Transfer')])
	n_type = fields.Selection([('in','IN'),('out','OUT')],default='in')
	
	n_mo_number = fields.Many2one("mrp.production","MO Number")
    	n_po_number = fields.Many2one("purchase.order","PO Number")
    	n_do_number = fields.Many2one("stock.picking","DO Number")
    	n_qc_number = fields.Many2one("stock.picking","QC Number")
    	
class storeMultiProduct(models.Model):
	_name="store.multi.product.data"
	_rec_name="product_id"

	@api.multi
	@api.depends('pkg_capicity','packages')
	def _get_free_qty(self):
		for rec in self:
			rec.n_free_qty=rec.pkg_capicity - rec.packages

	store_id =fields.Many2one('n.warehouse.placed.product','Store Name')
	product_id = fields.Many2one('product.product', string="Product")
	Packaging_type = fields.Many2one('product.packaging' ,string="Packaging",copy=True)
	
	pkg_capicity = fields.Float('Packages Capacity',default=0.0,help="maximum capacity of storage in packets, Caucluation based on product packaging")
	pkg_capicity_unit = fields.Many2one("product.uom",'Unit')
	
	free_qty = fields.Float('Free Quantity',compute="_get_free_qty")
	
	packages = fields.Float('No of Packages',default=0.0,help="Total No. of packets currently in Storage,Packages Calculate on the Basic of packaging")
	pkg_unit = fields.Many2one("product.uom",'Unit')
	
	total_quantity = fields.Float('Total Store Quantity',default=0.0, help="total quantity in product units")
	total_qty_unit = fields.Many2one("product.uom",'Unit')
		
