# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from openerp import api, fields, models, exceptions, _
from openerp.tools.translate import _
from openerp.exceptions import UserError, ValidationError
from openerp import fields
import openerp.addons.decimal_precision as dp
from datetime import datetime
import re
from dateutil.relativedelta import relativedelta
import math

class stockPicking(models.Model):
	_inherit = "stock.picking"

	@api.multi
	def _get_packaging_count(self):
		for rec in self:
			quantity = 0
			product_id=''
			if rec.pack_operation_product_ids:
				for line in rec.pack_operation_product_ids:
					product_id=line.product_id.product_tmpl_id
			elif rec.move_lines:
				for line in rec.move_lines:
					product_id=line.product_id.product_tmpl_id
					
			mo_ids=self.env['mrp.production'].search([('name','=',rec.origin)])
			if mo_ids:
				rec.packaging = mo_ids.n_packaging.id
			else:
				for packg in product_id.packaging_ids:
					if packg.pkgtype=='primary':
						rec.packaging=packg.id
						break
					
			pack_qty=rec.packaging.qty if rec.packaging else 1
			if rec.pack_operation_product_ids:
				for line in rec.pack_operation_product_ids:
					quantity += line.qty_done if line.qty_done else line.product_qty	
			else:
				for line in rec.move_lines_related:
					quantity += line.product_uom_qty
			print "H<<<<<<<<<<<<<<<<<<",quantity,pack_qty
			rec.packaging_count=math.ceil(float(quantity)/float(pack_qty)) if pack_qty else 0
			rec.packaging_unit =  rec.packaging.uom_id if rec.packaging else False
			rec.pallet_qty_unit = rec.packaging.uom_id if rec.packaging else False
			
			# qty / pallate
			for packg in product_id.packaging_ids:
				if packg.pkgtype=='secondary' and packg.unit_id.id==rec.packaging_unit.id:
					rec.pallet_size=packg.qty
			
			if rec.packaging_count and rec.pallet_size:	
				rec.total_no_pallets = math.ceil(float(rec.packaging_count)/float(rec.pallet_size))

	@api.onchange('packaging','packaging_unit','pallet_qty_unit')
	def get_uom_id(self):
		if self.packaging:
			self.packaging_unit=self.packaging.uom_id.id
			self.pallet_qty_unit=self.packaging.uom_id.id
		
	packaging = fields.Many2one('product.packaging' ,string="Packaging",compute='_get_packaging_count')
	packaging_count = fields.Integer(string="No of Packages",compute='_get_packaging_count')
	packaging_unit = fields.Many2one('product.uom',string="Packages unit",compute='_get_packaging_count')
	
	pallet_size = fields.Float("Qty/Pallet",compute='_get_packaging_count')
	pallet_qty_unit = fields.Many2one('product.uom',string="No of Packages",compute='_get_packaging_count')
	pallet_type = fields.Many2one('product.product',"Pallet Type")
     	total_no_pallets=fields.Float('Total Pallets',compute='_get_packaging_count')
     	store_ids = fields.One2many('picking.lot.store.location','picking_id','Store Location')
     	
     	@api.model
     	def create(self,vals):
     		res =super(stockPicking,self).create(vals)
     		if res.location_id.pre_ck:
     			res.ntransfer_type='pre_stock'
     		return res
     		
	@api.multi
	def action_first_validation(self):
		for rec in self:
			if rec.picking_type_id.code=='outgoing':  
				#if not rec.dispatch_doc: #and not rec.note:
					#raise UserError('Are you sure Proceed Delivery Dispatch without document.')      
				data=[]
				wizard_id=self.env['stock.store.location.wizard'].search([('picking','=',self.id)])
				wizard_id.unlink()
				data=self._get_bacthes(rec.origin)
				vals={'picking':rec.id,'locations':data}
				res_id=self.env['stock.store.location.wizard'].create(vals)
				if False:
					form_id = self.env.ref('api_inventory.store_locations_form_view_wizard_outgoing')
					return {
					'name' :'Select Store Location',
					'type': 'ir.actions.act_window',
					'view_type': 'form',
					'view_mode': 'form',
					'res_model': 'stock.store.location.wizard',
					'views': [(form_id.id, 'form')],
					'view_id': form_id.id,
					'target': 'new',
					'res_id':res_id.id,
				    }
		return super(stockPicking,self).action_first_validation_data()
		
	@api.multi
	def action_second_validation(self):
		super(stockPicking,self).action_second_validation()
		temp_id = self.env.ref('api_inventory.email_template_for_delivery_done')
                if temp_id:
	       		recipient_partners=self.sale_id.user_id.login
	       		group = self.env['res.groups'].search([('name', '=', 'Delivery Email')])
	       		user_obj = self.env['res.users'].browse(self.env.uid)
	       		for recipient in group.users:
       				if recipient.login != user_obj.partner_id.email:
		    	   		recipient_partners += ","+str(recipient.login) if recipient_partners else str(recipient.login)
		    	if recipient_partners:
		       		#body ="Delivery Order '{}' is Delivered to Customer '{}' \n \
		               	    # On Date: '{}' ".format(self.name,self.partner_id.name,self.delivery_date)  
                                body ='<li>Delivery Order No: '+str(self.name)+'</li>'
                                body +='<li>Customer Name:  '  +str(self.partner_id.name)+'</li>'
                                body +='<li>Delivered Date:  ' +str(self.delivery_date)+'</li>'
		       	        body +='<li> Please Find the attachment for Delivery Documents</li>'
		               
		       		body_html = self.pool['mail.template'].render_template(self._cr, self._uid, body, 'stock.picking',self.id, context=self._context)
		       		attch=([(6,0,[i.id for i in self.delivery_doc])])
		       		temp_id.write({'body_html': body_html, 'email_to':recipient_partners,'email_from': user_obj.partner_id.email,'attachment_ids':attch})
		       		if temp_id and temp_id.email_to:
		       			temp_id.send_mail(self.id)
                return True
     		
	@api.multi
	def _get_bacthes(self,origin):
		for res in self:
			data=[]
			for operation in res.pack_operation_product_ids:
				sale_id=self.env['sale.order'].search([('name','=',origin)])
				reserve_ids=self.env['n.warehouse.placed.product'].search([('product_id','=',operation.product_id.id)])
				batch_id=self.env['mrp.order.batch.number'].search([('sale_id','=',sale_id.id),('store_id','!=',False)])
				location,batches=[],[]
				qty=operation.qty_done
				flag=False
					
				for b_qty in batch_id:
					location.append(b_qty.store_id.id)
					batches.append(b_qty.id)
					if b_qty.convert_product_qty > qty:
						flag = True
						break
					qty -= b_qty.convert_product_qty
					if flag:
						break
					
				data.append((0,0,{'product_id':operation.product_id.id,
							'select_store':True,'locations_ids':[(6,0,location)],
							'batch_ids':[(6,0,batches)]}))
			return data
		
class pickinglotstore(models.Model):
	_name="picking.lot.store.location"
	
	picking_id = fields.Many2one('stock.picking','Move name')
	product_id = fields.Many2one('product.product','Product Name')
	store_id = fields.Many2one('n.warehouse.placed.product','Store Name')
	quantity = fields.Float('Quantity')
	unit_id = fields.Many2one('product.uom',"Packages unit")
	lot_number = fields.Many2one('stock.production.lot','Lot Number')
	batch_number = fields.Many2one('mrp.order.batch.number','Batch Number')

