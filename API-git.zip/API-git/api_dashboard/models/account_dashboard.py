from openerp import fields, models ,api, _
from openerp.exceptions import UserError, ValidationError
import logging
from datetime import datetime
import datetime
from dateutil.relativedelta import *
from datetime import date,datetime,timedelta
import openerp.addons.decimal_precision as dp
from openerp.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from openerp.tools.misc import formatLang
from urllib import urlencode
from urlparse import urljoin
_logger = logging.getLogger(__name__)

class account_journal(models.Model):
    _inherit = "account.journal"
#CH_N105 >>inherite field and add request type
    type = fields.Selection([
            ('sale', 'Sale'),
            ('purchase', 'Purchase'),
            ('cash', 'Cash'),
            ('bank', 'Bank'),
            ('general', 'Miscellaneous'),('request', 'Request'),
        ], required=True,
        help="Select 'Sale' for customer invoices journals."\
        " Select 'Purchase' for vendor bills journals."\
        " Select 'Cash' or 'Bank' for journals that are used in customer or vendor payments."\
        " Select 'General' for miscellaneous operations journals."\
        " Select 'Opening/Closing Situation' for entries generated for new fiscal years."\
	"Select request for dashboard show data for request for credits or payment terms")
   
    @api.multi
    def get_journal_dashboard_datas(self):
        currency = self.currency_id or self.company_id.currency_id
        number_to_reconcile = last_balance = account_sum = 0
        ac_bnk_stmt = []
        title = ''
        invoice_wait=0
        number_draft = number_waiting = number_late = sum_draft = sum_waiting = sum_late = 0
        if self.type in ['bank', 'cash']:
            last_bank_stmt = self.env['account.bank.statement'].search([('journal_id', 'in', self.ids)], order="date desc, id desc", limit=1)
            last_balance = last_bank_stmt and last_bank_stmt[0].balance_end or 0
            #Get the number of items to reconcile for that bank journal
            self.env.cr.execute("""SELECT COUNT(DISTINCT(statement_line_id)) 
                        FROM account_move where statement_line_id 
                        IN (SELECT line.id 
                            FROM account_bank_statement_line AS line 
                            LEFT JOIN account_bank_statement AS st 
                            ON line.statement_id = st.id 
                            WHERE st.journal_id IN %s and st.state = 'open')""", (tuple(self.ids),))
            already_reconciled = self.env.cr.fetchone()[0]
            self.env.cr.execute("""SELECT COUNT(line.id) 
                            FROM account_bank_statement_line AS line 
                            LEFT JOIN account_bank_statement AS st 
                            ON line.statement_id = st.id 
                            WHERE st.journal_id IN %s and st.state = 'open'""", (tuple(self.ids),))
            all_lines = self.env.cr.fetchone()[0]
            number_to_reconcile = all_lines - already_reconciled
            # optimization to read sum of balance from account_move_line
            account_ids = tuple(filter(None, [self.default_debit_account_id.id, self.default_credit_account_id.id]))
            if account_ids:
                amount_field = 'balance' if not self.currency_id else 'amount_currency'
                query = """SELECT sum(%s) FROM account_move_line WHERE account_id in %%s;""" % (amount_field,)
                self.env.cr.execute(query, (account_ids,))
                query_results = self.env.cr.dictfetchall()
                if query_results and query_results[0].get('sum') != None:
                    account_sum = query_results[0].get('sum')
        #TODO need to check if all invoices are in the same currency than the journal!!!!
        elif self.type in ['sale', 'purchase']:
            title = _('Bills to pay') if self.type == 'purchase' else _('Invoices owed to you')
            # optimization to find total and sum of invoice that are in draft, open state
            query = """SELECT state, amount_total,currency_id AS currency FROM account_invoice WHERE journal_id = %s AND state NOT IN ('paid', 'cancel');"""
            self.env.cr.execute(query, (self.id,))
            query_results = self.env.cr.dictfetchall()
            today = datetime.today()
            query = """SELECT amount_total, currency_id AS currency FROM account_invoice WHERE journal_id = %s AND date < %s AND state = 'open';"""
            self.env.cr.execute(query, (self.id, today))
            late_query_results = self.env.cr.dictfetchall()
            sum_draft = 0.0
            number_draft = 0
            number_waiting = 0
           
            for result in query_results:
                cur = self.env['res.currency'].browse(result.get('currency'))
                if result.get('state') in ['open','draft']:
                   if  fields.Date.context_today(self) < result.get('payment_date_inv'):
                       invoice_wait +=1
                if result.get('state') in ['draft', 'proforma', 'proforma2']:
                    number_draft += 1
                    sum_draft += cur.compute(result.get('amount_total'), currency)
                   
                elif result.get('state') == 'open':
                    number_waiting += 1
                    sum_waiting += cur.compute(result.get('amount_total'), currency)
            sum_late = 0.0
            number_late = 0
            for result in late_query_results:
                cur = self.env['res.currency'].browse(result.get('currency'))
                number_late += 1
                sum_late += cur.compute(result.get('amount_total'), currency)
	requests=[]
        #credit=self.env['res.partner.credit'].search([('state','=','request')])
       # if credit:
        #   credit=len(credit)
        if self.user_has_groups('base.group_system'): 
            requests = self.env['account.payment.term.request'].search([('state','=','requested'),('customer_id.customer','=',True)])
        elif self.user_has_groups('account.group_account_user'):
            requests = self.env['account.payment.term.request'].search([('state','=','requested'), ('accountant_id', 'in', [False, self.env.uid]),('customer_id.customer','=',True)])
	num_req = '0'
        if requests:
            num_req = len(requests)

        sup_request=[]
        if self.user_has_groups('base.group_system'): 
            sup_request = self.env['account.payment.term.request'].search([('state','=','requested'),('customer_id.supplier','=',True)])
        elif self.user_has_groups('account.group_account_user'):
            sup_request = self.env['account.payment.term.request'].search([('state','=','requested'), ('accountant_id', 'in', [False, self.env.uid]),('customer_id.supplier','=',True)])
	num_req_sup = '0'
        if sup_request:
            num_req_sup = len(sup_request)
	credt_req=0
	credt = self.env['res.partner.credit'].search([('state','=','request')])
	if credt:
                credt_req = len(credt)
        pending_rqst=self.env['purchase.order'].search([('state','=','awaiting')])
        lst_rqst=[]
        for pend in pending_rqst:
            if pend.management_user.id == self.env.user.id and not pend.approve_mgnt: 
               lst_rqst.append(pend.id)
            if pend.procurement_user.id == self.env.user.id and not pend.approve_prq: 
               lst_rqst.append(pend.id)
            
            if pend.inventory_user.id == self.env.user.id and not pend.approve_inv: 
               lst_rqst.append(pend.id)
        advance_payment=self.env['account.payment'].search([('partner_type', '=', 'customer'),('sale_id','!=',False),('state','=','draft')])
        lines=[]
        not_match="select order_id  from sale_order_line where qty_delivered != qty_invoiced and state ='sale'"
        self._cr.execute(not_match)
        lines=[i[0] for i in self._cr.fetchall()]
        
        return {
            'number_to_reconcile': number_to_reconcile,
            'account_balance': formatLang(self.env, account_sum, currency_obj=self.currency_id or self.company_id.currency_id),
            'last_balance': formatLang(self.env, last_balance, currency_obj=self.currency_id or self.company_id.currency_id),
            'number_draft': number_draft,
            'number_waiting': number_waiting,
            'number_late': number_late,
            'sum_draft': formatLang(self.env, sum_draft or 0.0, currency_obj=self.currency_id or self.company_id.currency_id),
            'sum_waiting': formatLang(self.env, sum_waiting or 0.0, currency_obj=self.currency_id or self.company_id.currency_id),
            'sum_late': formatLang(self.env, sum_late or 0.0, currency_obj=self.currency_id or self.company_id.currency_id),
            'currency_id': self.currency_id and self.currency_id.id or self.company_id.currency_id.id,
            'bank_statements_source': self.bank_statements_source,
            'title': title, 
            'num_req' : num_req,
            'invoice_wait':invoice_wait,
            'num_req_sup':num_req_sup,
	    'credit_request':credt_req,
            'pending_rqst':len(lst_rqst),
            'advance_payment':len(advance_payment),
            'not_match':len(set(lines))
        }
    
    @api.multi
    def open_action_payment_term(self):
        domain=[]
	requests=[]
        if self._context.get('type') == 'customer':
		if self.user_has_groups(' base.group_system'): 
		    requests = self.env['account.payment.term.request'].search([('customer_id.customer','=',True)])
		elif self.user_has_groups('account.group_account_user'):
		    requests = self.env['account.payment.term.request'].search([('accountant_id', 'in', [False, self.env.uid]),('customer_id.customer','=',True)])
        if self._context.get('type') == 'supplier':
		if self.user_has_groups(' base.group_system'): 
		    requests = self.env['account.payment.term.request'].search([('customer_id.supplier','=',True)])
		elif self.user_has_groups('account.group_account_user'):
		    requests = self.env['account.payment.term.request'].search([('accountant_id', 'in', [False, self.env.uid]),('customer_id.supplier','=',True)])
	tree_id=self.env.ref('gt_order_mgnt.account_payment_term_requested_tree_view').id
	form_id=self.env.ref('gt_order_mgnt.account_payment_term_requested_form_view').id,
        return {
            'name': 'Requested Payment Term',
            'view_type': 'form',
            'view_mode': 'tree',
            'res_model': 'account.payment.term.request',
	    'views': [(tree_id, 'tree'), (form_id, 'form')],
            'type': 'ir.actions.act_window',
            'domain' : [('id', 'in', requests._ids)],
            'context' : {'search_default_requested' : 1}
        }
   
    @api.multi
    def open_action_invoice_wait(self):
        today_date=fields.Date.context_today(self)
        requests = self.env['account.invoice'].search([('journal_id.type','=','sale'),('state','in',['open','draft'])])
        for req in requests:
            if today_date < req.payment_date_inv: 
               pass
             
        domain=[('journal_id.type','=','sale'),('payment_date_inv','>',today_date)]
        if self.user_has_groups(' base.group_system'): 
            requests = self.env['account.invoice'].search([])
        elif self.user_has_groups('account.group_account_user'):
            requests = self.env['account.invoice'].search([('accountant_id', 'in', [False, self.env.uid])])
        return {
            'name': 'Requested Awaiting Invoice ',
            'view_type': 'form',
            'view_mode': 'tree',
            'res_model': 'account.invoice',
            'view_id': self.env.ref('account.invoice_tree').id,
            'type': 'ir.actions.act_window',
            'domain' :[('journal_id.type','=','sale'),('payment_date_inv','>',today_date)],
            'context' : {'search_default_requested' : 1}
        }

    @api.multi
    def open_action_credit_request(self):
        tree_id=form_id=model=name=''
        domain=[]
        context=''
        if self._context.get('customer'):
           list_ids=[]
	   for rec in self.env['res.partner.credit'].search([('state', '=','request')]):
		list_ids.append(rec.partner_id.id)
           domain=[('id','in',list_ids)]
	   tree_id=self.env.ref('gt_order_mgnt.customer_credit_tree_ac').id #customer_credit_tree').id
	   form_id=self.env.ref('gt_order_mgnt.customer_credit_form_ac').id #customer_credit_form').id
           model='res.partner'
           name='Requested Customer Credit'
        if self._context.get('payment'):
	   tree_id=self.env.ref('account.view_account_payment_tree').id #customer_credit_tree').id
	   form_id=self.env.ref('account.view_account_payment_form').id #customer_credit_form').id
           domain=[('partner_type', '=', 'customer'),('sale_id','!=',False),('state','=','draft')]
           model='account.payment'
           name='Sale Order Advance Payment list'

	if self._context.get('not_match'):
           lines=[]
	   not_match="select order_id  from sale_order_line where qty_delivered != qty_invoiced and state ='sale'"
           self._cr.execute(not_match)
           lines=[i[0] for i in self._cr.fetchall()]
           domain=[('id', 'in', lines)]	
           tree_id = self.env.ref('sale.view_order_tree').id
           form_id = self.env.ref('sale.view_order_form').id
           model='sale.order'
           name='Sale Order in which DO qty is not equal to invocie qty'
           context={'show_sale':True}
        return {
            'name':name ,
            'view_type': 'form',
            'view_mode': 'tree',
            'res_model': model,
	    'views': [(tree_id, 'tree'), (form_id, 'form')],
            'type': 'ir.actions.act_window',
            'domain' : domain,
            'context':context
        }

    @api.multi
    def open_po_request(self):
	if self._context.get('request_pending'):
                pending_rqst=self.env['purchase.order'].search([('state','=','awaiting')])
		lst_rqst=[]
		for pend in pending_rqst:
		    if pend.management_user.id == self.env.user.id and not pend.approve_mgnt: 
		       lst_rqst.append(pend.id)
		    if pend.procurement_user.id == self.env.user.id and not pend.approve_prq: 
		       lst_rqst.append(pend.id)
		    
		    if pend.inventory_user.id == self.env.user.id and not pend.approve_inv: 
		       lst_rqst.append(pend.id)
		domain=[('id','in',lst_rqst)]

		_name='Pending Purchase Approval'
		model='purchase.order'
		rq_tree = self.env.ref('purchase.purchase_order_tree', False)
                rq_form =self.env.ref('purchase.purchase_order_form',False)
        if rq_tree:
            views=[]
            if rq_tree and rq_form:
               views=[(rq_tree.id, 'tree'),(rq_form.id, 'form')]
            else:
               views=[(rq_tree.id, 'tree')]
            return {
		'name':_name,
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'tree',
                'res_model': model,
		'views': views,
                'view_id': rq_tree.id,
                'target': 'current',
		'domain':domain,
            }

