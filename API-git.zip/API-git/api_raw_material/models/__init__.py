# -*- encoding: utf-8 -*-
##############################################################################
# For copyright and license notices, see __openerp__.py file in root directory

import mrp
import stock
import product
import raw_material
import purchase
import workorder
