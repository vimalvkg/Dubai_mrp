# -*- coding: utf-8 -*-
##############################################################################
#
#
#    Copyright (C) 2013-Today(www.aalmirplastic.com).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import fields, models ,api, _
from openerp.tools import amount_to_text_fr
from openerp import tools
from datetime import datetime, date, timedelta
from openerp.tools import float_is_zero, float_compare
from openerp.tools.translate import _
from openerp.tools import amount_to_text_en
from openerp.tools.amount_to_text_en import amount_to_text
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT
from openerp.exceptions import UserError
from urllib import urlencode
from urlparse import urljoin
import json
import math


class JournalVoucher(models.Model):
	_name='journal.voucher'
	_inherit = ['mail.thread']

	@api.model
	def default_currency(self):
		return self.env.user.company_id.currency_id.id or False

	name=fields.Char()
	partner_id=fields.Many2one('res.partner', 'Partner')
	currency_id=fields.Many2one('res.currency', 'Currency', default=default_currency)
	journal_id=fields.Many2one('account.journal', 'Journal')
	move_id=fields.Many2one('account.move', 'Journal Entries')
	date=fields.Date('Date',default=fields.Date.context_today)    
	voucher_line=fields.One2many('journal.voucher.line','voucher_id')
	note=fields.Text('Narration')
	state=fields.Selection([('draft','Unposted'),('posted','Posted')], default='draft', string='Status',copy=False,)

	@api.model
	def create(self, vals):
		vals['name'] = self.env['ir.sequence'].next_by_code('journal.voucher')
		voucher = super(JournalVoucher, self).create(vals)
		voucher.assert_balanced()
		return voucher

	@api.multi
	def write(self, vals):
		res = super(JournalVoucher, self).write(vals)
		self.assert_balanced()
		return res

	@api.multi
	def assert_balanced(self):
		debit=sum(line.debit for line in self.voucher_line)
		credit=sum(line.credit for line in self.voucher_line)
		print"oooooooooooooo",credit, debit
		if credit != debit:
			raise UserError(_("Cannot create unbalanced journal entry."))

	@api.multi
	def post_voucher(self):
		for record in self:
			vals=[]
			print"_-----------------",record.partner_id.name
			print"HHhhhhhhhhhh",
			move=self.env['account.move'].create({'date':record.date,
									'journal_id':record.journal_id.id,'name':record.name,'narration':record.note})
			print"UUUUUUUUUUuuuu",move.partner_id.name,self.env.user.company_id.currency_id.id,record.currency_id.id
			record.move_id=move.id
			for line in record.voucher_line:
				line=self.env['account.move.line'].create({'account_id':line.account_id.id,'name':line.name,
								'ref':record.name,
								#'currency_id':record.currency_id.id if self.env.user.company_id.currency_id.id != record.currency_id.id else False,
								#'amount_currency':line.debit if self.env.user.company_id.currency_id.id != record.currency_id.id else 0.0,
								'debit':line.debit,'credit':line.credit,'move_id':move.id,
								'partner_id':record.partner_id.id})
				print"LIIIILIIIiiiiii",line
		
		return self.write({'state': 'posted'})

class JournalVoucherLine(models.Model):
	_name='journal.voucher.line'

	account_id=fields.Many2one('account.account','Account')
	debit=fields.Float('Debit')
	credit=fields.Float('Credit')
	name=fields.Char('Label')
	voucher_id=fields.Many2one('journal.voucher')
