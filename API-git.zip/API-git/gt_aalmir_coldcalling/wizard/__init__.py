# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import crm_lead_to_opportunity
import crm_lead_lost
import mail_compose_message
import import_coldcalling_list
import assign_to_other_salesman
import invite
#import mail_thread
