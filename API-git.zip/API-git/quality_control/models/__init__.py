# -*- encoding: utf-8 -*-
##############################################################################
# For copyright and license notices, see __openerp__.py file in root directory

import quality
import quality_inspection
import quality_test
import mrp
import stock
import dashboard
import product
