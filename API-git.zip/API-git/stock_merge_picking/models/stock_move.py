from datetime import date, datetime,timedelta
from dateutil import relativedelta
import json
import time
import sets

import openerp
from openerp.osv import fields, osv
from openerp.tools.float_utils import float_compare, float_round
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
from openerp import SUPERUSER_ID, api, models
import openerp.addons.decimal_precision as dp
from openerp.addons.procurement import procurement
import logging
from openerp.exceptions import UserError


class stock_picking(osv.osv):
    _inherit='stock.picking'

    def create(self,cr,uid,vals,context=None):
	#CH_N106 add code to get main LPO in DO as default >>>
	if vals.get('origin'):
		search_id=self.pool.get('sale.order').search(cr,uid,[('name','=',vals.get('origin'))])
                val=[]
		if search_id:
			for rec in self.pool.get('sale.order').browse(cr,uid,search_id):
				n_id=self.pool.get('customer.upload.doc').search(cr,uid,[('sale_id_lpo','=',rec.id)])
                                ### Add multiple lpo in delivery
                                if n_id:
                                   for lpo_id in n_id:
                                        val.append((4,lpo_id))
                                   vals.update({'lpo_document_id':val})
				#if n_id:
					#vals.update({'lpo_document_id':n_id[0]})
	#CH_N106 <<<
	return super(stock_picking,self).create(cr,uid,vals)
   
    def _state_get(self, cr, uid, ids, field_name, arg, context=None):
        '''The state of a picking depends on the state of its related stock.move
            draft: the picking has no line or any one of the lines is draft
            done, draft, cancel: all lines are done / draft / cancel
            confirmed, waiting, assigned, partially_available depends on move_type (all at once or partial)
        '''
        res = {}
        for pick in self.browse(cr, uid, ids, context=context):
            if not pick.move_lines:
                res[pick.id] = pick.launch_pack_operations and 'assigned' or 'draft'
                continue
            if any([x.state == 'draft' for x in pick.move_lines]):
                res[pick.id] = 'draft'
                continue
            if all([x.state == 'cancel' for x in pick.move_lines]):
                res[pick.id] = 'cancel'
                continue
            if all([x.state in ('cancel', 'done') for x in pick.move_lines]):
                res[pick.id] = 'done'
                continue
	    
            order = {'confirmed': 0, 'waiting': 1, 'assigned': 2,'transit':3,'delivered':4,}
            order_inv = {0: 'confirmed', 1: 'waiting', 2: 'assigned', 3: 'transit', 4: 'delivered'}
            lst = [order[x.state] for x in pick.move_lines if x.state not in ('cancel', 'done')]
            if pick.move_type == 'one':
                res[pick.id] = order_inv[min(lst)]
            else:
                #we are in the case of partial delivery, so if all move are assigned, picking
                #should be assign too, else if one of the move is assigned, or partially available, picking should be
                #in partially available state, otherwise, picking is in waiting or confirmed state
                res[pick.id] = order_inv[max(lst)]
                if not all(x == 2 for x in lst):
                    if any(x == 2 for x in lst):
                        res[pick.id] = 'partially_available'
                    else:
                        #if all moves aren't assigned, check if we have one product partially available
                        for move in pick.move_lines:
                            if move.partially_available:
                                res[pick.id] = 'partially_available'
                                break
        return res
    
    def _get_pickings(self, cr, uid, ids, context=None):
        res = set()
        for move in self.browse(cr, uid, ids, context=context):
            if move.picking_id:
                res.add(move.picking_id.id)
        return list(res)

    _columns={
               'state': fields.function(_state_get, type="selection", copy=False,
            store={
                'stock.picking': (lambda self, cr, uid, ids, ctx: ids, ['move_type', 'launch_pack_operations'], 20),
                'stock.move': (_get_pickings, ['state', 'picking_id', 'partially_available'], 20)},
            selection=[
                ('draft', 'Draft'),
                ('cancel', 'Cancelled'),
                ('waiting', 'Waiting Another Operation'),
                ('confirmed', 'Waiting Availability'),               
                ('partially_available', 'Partially Available'),
                ('assigned', 'Available'),
		('transit','Ready To Dispatch'),
                ('done', 'Done'),
                ('delivered','Delivered'),
                ], string='Status', readonly=True, select=True, track_visibility='onchange',
            help="""
                * Draft: not confirmed yet and will not be scheduled until confirmed\n
                * Waiting Another Operation: waiting for another move to proceed before it becomes automatically available (e.g. in Make-To-Order flows)\n
                * Waiting Availability: still waiting for the availability of products\n
                * Partially Available: some products are available and reserved\n
                * Ready to Transfer: products reserved, simply waiting for confirmation.\n
                * Transferred: has been processed, can't be modified or cancelled anymore\n
                * Cancelled: has been cancelled, can't be confirmed anymore"""
        ),
            }
#CH_N111 add code to get  sale_order sale_id in quality form 
    @api.depends('move_lines')
    def _compute_sale_id(self):
        for picking in self:
            sale_order = False
            for move in picking.move_lines:
                if move.procurement_id.sale_line_id:
                    sale_order = move.procurement_id.sale_line_id.order_id
                    break
		elif move.n_sale_line_id:
			sale_order = move.n_sale_line_id.order_id
            picking.sale_id = sale_order.id if sale_order else False
   
    
    def action_first_validation_data(self, cr, uid, ids, context=None):
        pickings = self.browse(cr, uid, ids, context=context)
        picking=self.pool.get('stock.picking')
	sale_status_line=self.pool.get('sale.order.line.status')
        for pick in pickings:
            move_ids = [x.id for x in pick.move_lines if x.state in ['transit']]
	    pick.state='done'
            pick.dispatch_date=date.today()
	
	    #CH_N061 add code to deduct quantity which are dispatch >>>
	    #for line in pick.pack_operation_product_ids:
		#qry="UPDATE stock_quant SET qty =qty-"+str(line.qty_done)+" where location_id = "+str(line.location_id.id)+" and product_id="+str(line.product_id.id)
		#cr.execute(qry)
	    #CH_N061 end <<<<
            #if pick.mark_as_final:
             #  pick_search=picking.search(cr, uid,[('sale_id','=',pick.sale_id.id),('id','!=',pick.id),('state','in',('confirmed','assigned', 'draft','partially_available','awaiting'))],context=context)
             #  for rec in picking.browse(cr, uid, pick_search, context=context):
              #     rec.action_cancel()
            for line in pick.pack_operation_product_ids:
                # add product in sale order line  when delivered qty is greater than order qty
		if line.n_sale_order_line:
                        if line.n_sale_order_line.product_uom_qty < line.n_sale_order_line.qty_delivered:
                           body="Add New Order Line in Sale Order Because Extra Qty Delivered."
                           qty=line.n_sale_order_line.qty_delivered - line.n_sale_order_line.product_uom_qty
                           body +='<li>Delivery No : ' +str(pick.name) +'</li>'
                           body +='<li>Product Name: ' +str(line.product_id.name)+'</li>'
                           body +='<li>Previous qty: ' +str(line.n_sale_order_line.product_uom_qty)+'</li>'
			   new_id=sale_status_line.search(cr, uid, [('n_string','=','extra_product')],limit=1)
			   self.pool.get('sale.order').write(cr,uid,line.n_sale_order_line.order_id.id,{'state':'done'})
                           res=self.pool.get('sale.order.line').search(cr,uid,[('qty_exceed','=',True),('product_id','=',line.product_id.id)],context=context)
                           if res:
                              self.pool.get('sale.order.line').write(cr,uid,res,{'product_uom_qty':qty, 'qty_invoiced':qty, 'approve_m':True})
                              body +='<li>Extra qty: ' +str(qty)+'</li>'
                              pick.sale_id.message_post(body=body)
                           if not res:
                              res1=self.pool.get('sale.order.line').create(cr,uid,{'order_id':line.n_sale_order_line.order_id.id,
							'product_id':line.product_id.id ,'name':line.product_id.name,
							'product_uom':line.n_sale_order_line.product_uom.id,'qty_exceed':True,
							'n_status_rel':[(6,0,new_id)],
                                                        'product_uom_qty':qty, 'price_unit':line.n_sale_order_price,'approve_m':True})
                              
                              body +='<li>Extra qty: ' +str(qty)+'</li>'
                              pick.sale_id.message_post(body=body)
			   self.pool.get('sale.order').write(cr,uid,line.n_sale_order_line.order_id.id,{'state':'sale'})
			#else:
		#CH_N078 >>> add code to update schedule dspatch Date >>>>  #CH_N088 code is comented due to date is calculate form def
				#n_client_date=''
		    		#records=self.pool.get('mrp.delivery.date').search(cr,uid,[('n_line_id1','=',line.n_sale_order_line.id)],order='id desc',limit=1)
		    		#for line1 in self.pool.get('mrp.delivery.date').browse(cr,uid,records):
				#	if line1.n_schdule_date and line1.n_picking_id.state =='transit':
				#		n_client_date = line1.n_dispatch_date
				#if line.n_sale_order_line.n_manu_date:
				#	n_client_date=datetime.strptime(line.n_sale_order_line.n_manu_date,'%Y-%m-%d') + timedelta(1)
				#elif line.n_sale_order_line.n_client_date:
				#	n_client_date=datetime.strptime(line.n_sale_order_line.n_client_date,'%Y-%m-%d') - timedelta(line.n_sale_order_line.n_transit_time)		
				#line.n_sale_order_line.n_schdule_date=n_client_date
				
		#CH_N078 <<<<< end				
		#CH_N062 UPdate status in reserve history >>>
			qry="UPDATE reserve_history SET n_status ='delivered' where id =(select id from reserve_history where n_status ='r_t_dispatch' and sale_line="+str(line.n_sale_order_line.id)+" and picking_id="+str(pick.id)+" order by id asc limit 1)"
			cr.execute(qry)
		#CH_N062<<<<<<<<<<<<
			line.n_sale_order_line.reserved_qty -= line.qty_done
			line.n_sale_order_line.product_id.n_reserve_qty -= line.qty_done

			if line.n_sale_order_line.product_uom_qty <= line.n_sale_order_line.qty_delivered:
				status_list = []
				search_id=sale_status_line.search(cr, uid, [('n_string','=','dispatch')],limit=1)
				if search_id:
					status_list.append((4,search_id[0]))
				new_id=sale_status_line.search(cr, uid, [('n_string','=','r_t_dispatch')],limit=1)
				if new_id:
					status_list.append((3,new_id[0]))
				self.pool.get('sale.order.line').write(cr,uid,line.n_sale_order_line.id,{'n_status_rel':status_list})
				n_type='full'
					
			else:
				status_list = []
				search_id = sale_status_line.search(cr, uid, [('n_string','=','partial_dispatch')],limit=1)
				if search_id:
					status_list.append((4,search_id[0]))
				new_id=sale_status_line.search(cr, uid, [('n_string','=','r_t_dispatch')],limit=1)
				if new_id:
					status_list.append((3,new_id[0]))
				if status_list:
					self.pool.get('sale.order.line').write(cr,uid,line.n_sale_order_line.id,{'n_status_rel':status_list})
				n_type='partial'

			exist_rec=self.pool.get('mrp.delivery.date').search(cr,uid,[('n_picking_id','=',pick.id),('n_line_id1','=',line.n_sale_order_line.id)])
			if not exist_rec:
				self.pool.get('mrp.delivery.date').create(cr,uid,{'n_dispatch_date_d':date.today(),
							'n_status':'dispatch','n_picking_id':pick.id,
							'n_line_id1':line.n_sale_order_line.id,'n_type':'partial'})
			else:
				self.pool.get('schedule.delivery.date.history').create(cr,uid,{
										'n_nextdate':date.today(),
										'n_status':'dispatch',
										'n_picking_id':line.picking_id.id,
										'n_line_id':line.n_sale_order_line.id,
										'delivery_id':exist_rec[0]})
				self.pool.get('mrp.delivery.date').write(cr,uid,exist_rec[0],{'n_status':'dispatch','n_dispatch_date_d':date.today()})

			line.n_sale_order_line._get_schedule_date()
            self.pool.get('stock.move').action_first_validation(cr, uid, move_ids, context=context)
	    for line in pick.pack_operation_product_ids:
                # add product in sale order line  when delivered qty is greater than order qty
		if line.n_sale_order_line:
	    		line.n_sale_order_line._get_schedule_date()
        return True
    
    def action_second_validation(self, cr, uid, ids, context=None):
        """ Changes state of picking to available if moves are confirmed or waiting.
        @return: True
        """
        pickings = self.browse(cr, uid, ids, context=context)
        for pick in pickings:
	    if  not pick.delivery_date:
               raise UserError('Please Add Delivery Date')
            if  not pick.delivery_doc:
               raise UserError('Please Add Delivery Receipt........... ')
            move_ids = [x.id for x in pick.move_lines if x.state in ['done']]
	    pick.state='delivered'
	    if not pick.delivery_date:
	            pick.delivery_date=date.today()
	    record_dic={}
	    for line in pick.pack_operation_product_ids:
		sale_line=line.n_sale_order_line
		if sale_line:
			if not record_dic.get(sale_line.id):
				record_dic.update({sale_line.id:[line.product_id.id,line.qty_done,sale_line.product_uom_qty]})
			else:
				qty=record_dic.get(line.n_sale_order_line.id)[0]
				record_dic.update({sale_line.id:[line.product_id.id,line.qty_done+qty,sale_line.product_uom_qty]})
	   
	    for key,val in record_dic.items():
		cr.execute("select sum(res_qty) from reserve_history where n_status='delivered' and sale_line="+str(key))
		qty=cr.fetchone()[0]
		status_list=[]
		if (qty)>=val[2]:
			
			search_id=self.pool.get('sale.order.line.status').search(cr, uid, [('n_string','=','delivered')],limit=1)
			if search_id:
				status_list.append((4,search_id[0]))
			new_id=self.pool.get('sale.order.line.status').search(cr, uid, [('n_string','in',('partial_delivery','partial_dispatch','dispatch'))])
			for rec in new_id:
				status_list.append((3,rec))
		elif (qty)< val[2]:
			search_id=self.pool.get('sale.order.line.status').search(cr, uid, [('n_string','=','partial_delivery')],limit=1)
			if search_id:
				status_list.append((4,search_id[0]))
			new_id=self.pool.get('sale.order.line.status').search(cr, uid,[('n_string','in',('partial_dispatch','dispatch'))])
			for rec in new_id:
				status_list.append((3,rec))
		if status_list:		#CH_N123 add code to update status in sale support
			self.pool.get('sale.order.line').write(cr,uid,key,{'n_status_rel':status_list})
		delivery_ids=self.pool.get('mrp.delivery.date').search(cr,uid,[('n_picking_id','=',pick.id),('n_line_id1','=',key)])
		if delivery_ids:		#update delivery date in sale support delivery date table
			self.pool.get('mrp.delivery.date').write(cr,uid,delivery_ids[0],{'n_delivery_date':pick.delivery_date,
								'n_status':'delivered'})
		sale_ids=self.pool.get('sale.order.line').browse(cr,uid,[key])
		sale_ids._get_schedule_date()
            self.pool.get('stock.move').action_second_validation(cr, uid, move_ids, context=context)
        return True

class stock_move(osv.osv):
    _inherit='stock.move'
    _columns={
              
              
        'state': fields.selection([('draft', 'New'),
                                   ('cancel', 'Cancelled'),
                                   ('waiting', 'Waiting Another Move'),
                                   ('confirmed', 'Waiting Availability'),                                  
                                   ('assigned', 'Available'),
                                   ('done', 'Done'),
                                   ('transit','Ready To Dispatch'),
                                   ('delivered','Delivered'),
                                   ], 'Status', readonly=True, select=True, copy=False,
                 help= "* New: When the stock move is created and not yet confirmed.\n"\
                       "* Waiting Another Move: This state can be seen when a move is waiting for another one, for example in a chained flow.\n"\
                       "* Waiting Availability: This state is reached when the procurement resolution is not straight forward. It may need the scheduler to run, a component to me manufactured...\n"\
                       "* Available: When products are reserved, it is set to \'Available\'.\n"\
                       "* Done: When the shipment is processed, the state is \'Done\'."), 
	'n_sale_line_id':fields.related('procurement_id','sale_line_id',type='many2one',relation='sale.order.line',string='Sale Order Line')     #CH_N055
            }
    
    def action_first_validation(self, cr, uid, ids, context=None):
        """ Changes the state to assigned.
        @return: True
        """
	move = self.browse(cr, uid, ids, context=context)
	for moves in move:
	    if moves.state=='transit':
	       res = self.write(cr, uid, ids, {'state': 'done'}, context=context)
            return res
      
    
    def action_second_validation(self, cr, uid, ids, context=None):
        """ Changes the state to assigned.
        @return: True
        """
        move = self.browse(cr, uid, ids, context=context)
        for moves in move:
		if moves.state=='done':
               		res = self.write(cr, uid, ids, {'state': 'delivered'}, context=context)
        	return res

    def write(self,cr,uid,ids,vals,context=None):
	super(stock_move,self).write(cr,uid,ids,vals,context)

    def create(self,cr,uid,vals,context=None):
	#CH_N055 add code to get line id in stock move #proper working is need to be check
	sale_name=vals.get('origin')
	product_id = vals.get('product_id')
	if sale_name and product_id :
		sale_id=self.pool.get('sale.order').search(cr,uid,[('name','=',sale_name)])
		if sale_id:
			#line_id=self.pool.get('sale.order.line').search(cr,uid,[('order_id','=',sale_id[0]),('product_id','=',product_id)])
			#if line_id:
			#	vals.update({'n_sale_line_id':line_id[0]})
			for rec in self.pool.get('sale.order').browse(cr,uid,sale_id):
                                if rec.client_date:
				   vals.update({'date_expected':rec.client_date})

		#mrp_id=self.pool.get('mrp.production').search(cr,uid,[('name','=',sale_name)])
		#if mrp_id:
		#	for rec in self.pool.get('mrp.production').browse(cr,uid,mrp_id):
		#		if rec.sale_line:
		#			vals.update({'n_sale_line_id':rec.sale_line.id})

	#po_id=self.pool.get('purchase.order').search(cr,uid,[('name','=',sale_name)])
	#if po_id:
	#	for rec in self.pool.get('purchase.order').browse(cr,uid,po_id):
	#		if rec.sale_line:
	#			vals.update({'n_sale_line_id':rec.sale_line.id})
	#		if rec.n_request_date:
	#			vals.update({'date_expected':rec.n_request_date})
#
	return super(stock_move,self).create(cr,uid,vals)

