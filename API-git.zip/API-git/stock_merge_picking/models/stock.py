# -*- coding: utf-8 -*-
from openerp import models, fields, api,_
from openerp import tools
from datetime import datetime, date, timedelta,time
from openerp.tools.translate import _
from openerp.tools.float_utils import float_compare, float_round
from openerp.exceptions import UserError
from urlparse import urljoin
from urllib import urlencode
from openerp.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT

class stock_picking(models.Model):
    _inherit = "stock.picking"

    merge_notes= fields.Text("Merge Notes")
    total_deliver_qty=fields.Float('Total Qty', compute='total_delivered_quantity')
    n_sale_order_line =fields.Many2one('sale.order.line','Sale order line')

    n_bool = fields.Boolean("Change Min Date",compute='_n_get_schedule_date') #CH_N072 get field for to take proper date
    return_raw_picking=fields.Boolean('Return Raw material Picking filter')

    @api.multi
    @api.depends('min_date')
    def _n_get_schedule_date(self):
        for record in self:
		n_date=record.min_date
		record.min_date=False
		if record.state not in ('transit','done','delivered','cancel') and record.picking_type_id.code =='outgoing':
			delivery_id=self.env['mrp.delivery.date'].search([('n_picking_id','=',record.id)],order="id desc",limit=1)
			if delivery_id:
				n_date=delivery_id.n_dispatch_date_d
			else:
				sale_id=self.env['sale.order'].search([('name','=',record.origin)])
				s_date=False
			   	for rec in sale_id.order_line:
					if rec.n_schdule_date:
						if not s_date :
							s_date=rec.n_schdule_date
						elif rec.n_schdule_date < s_date:
							s_date=rec.n_schdule_date
					else:
						if rec.n_client_date:
							n_date=datetime.strptime(rec.n_client_date,'%Y-%m-%d')-timedelta(days=int(rec.n_transit_time))
				if s_date:
					n_date=s_date
			if n_date:
				self.env.cr.execute("UPDATE stock_picking set min_date='"+str(n_date)+"' where id="+str(record.id))

    @api.multi
    @api.depends('pack_operation_product_ids')
    def total_delivered_quantity(self):
        for record in self:
            for pack in record.pack_operation_product_ids:
                if pack:
                   record.total_deliver_qty=sum(line.qty_done for line in pack)
#CH_N069 >>> code to check delivery qty

    '''@api.multi
    def do_new_transfer(self):
	for rec in self:
		if rec.picking_type_id.code=='outgoing':
			for n_line in rec.pack_operation_product_ids:
				if n_line.n_sale_order_line:
					if n_line.n_reserve_qty==0.0:
						raise UserError(_("You dont have any reserve quantity to create Delivery order of the product"))
					if n_line.qty_done==0.0:
						raise UserError(_("Enter Done Quantity to create Delivery of the product or if you don't  then remove product from list"))
					if n_line.n_reserve_qty < n_line.qty_done:
						raise UserError(_("Please enter done quantity less than or equal Reserve to create Delivery Order"))
					if n_line.product_qty < n_line.qty_done:
						raise UserError(_("Please enter done quantity less than or equal TO Quantty for creating Delivery Order"))
	return super(stock_picking,self).do_new_transfer()'''
#CH_N069 <<<
#CH_N053>>>>
    @api.multi
    def do_transfer(self):
	for rec in self:
		if rec.picking_type_id.code=='incoming' and not self._context.get('do_only_split'): 
			po_ids=self.env['purchase.order'].search([('name','=',rec.origin)])
			if po_ids:
				for p_line in po_ids.order_line:
					for n_line in rec.pack_operation_product_ids:
						if p_line.product_id.id == n_line.product_id.id:
							n_qty= n_line.qty_done if n_line.qty_done else n_line.product_qty
			
							n_status_rel=[]
							recipient_partners=str(po_ids.request_id.n_sale_order_line.order_id.user_id.login)
							if po_ids.production_ids:
								search_id=self.env['sale.order.line.status'].search([('n_string','=','manufacture')],limit=1) ## add status
								if search_id:
									n_status_rel.append((4,search_id.id))
								po_ids.request_id.n_state='scheduled'
								if po_ids.request_id.n_category.cat_type=='film':
									for usr in self.env['res.groups'].search([('name', '=', 'group_film_product')]).users:
					    					recipient_partners += ","+str(usr.login)
								if po_ids.request_id.n_category.cat_type=='injection':
									for usr in self.env['res.groups'].search([('name', '=', 'gropu_injection_product')]).users:
						    				recipient_partners += ","+str(usr.login)
							else:	
								search_id=self.env['sale.order.line.status'].search([('n_string','=','quality_check')],limit=1) ## add status
								if search_id:
									n_status_rel.append((4,search_id.id))

                                                                if po_ids.request_id:
								   po_ids.request_id.n_state='done'
								for usr in self.env['res.groups'].search([('name', '=', 'Sales Support Email')]).users:
					    				recipient_partners += ","+str(usr.login)
								
							if n_qty >= p_line.product_qty:
								new_id=self.env['sale.order.line.status'].search([('n_string','=','purchase')],limit=1) ## remove status
								if new_id:
									n_status_rel.append((3,new_id.id))
							if po_ids.request_id:
                                                                #ADD VML
                                                                vals={'product_id':po_ids.request_id.n_product_id.id,
                                                              'res_qty':n_qty,'n_status':'reserve',
                                                              'n_reserve_Type':'po',
						              'res_date':date.today(),
                                                               'sale_line':po_ids.request_id.n_sale_order_line.id
                                                               }
                                                                ids=self.env['reserve.history'].create(vals)
								self.env['sale.order.line'].sudo().browse(po_ids.request_id.n_sale_order_line.id).write({'n_status_rel':n_status_rel, 'reserved_qty':(po_ids.request_id.n_sale_order_line.reserved_qty + n_qty)}) 

								po_ids.request_id.n_product_id.n_reserve_qty += n_qty

			#CH_N069 <<<
			#CH_N078 >>> add code to send mail on production complete >>>
								temp_id = self.env.ref('gt_order_mgnt.email_template_MRP_complete')
								if temp_id:
								
									user_obj = self.env['res.users'].browse(self.env.uid)
									base_url = self.env['ir.config_parameter'].get_param('web.base.url')
									query = {'db': self._cr.dbname}
									fragment = {
									    'model': 'sale.order.line',
									    'view_type': 'form',
									    'id': po_ids.request_id.n_sale_order_line.id,
									}
									url = urljoin(base_url, "/web?%s#%s" % (urlencode(query), urlencode(fragment)))

									body_html = """<div>
						    <p> <strong>Product Requset is Complete </strong></p><br/>
						    <p>Dear Sir/Madam,<br/>
							Your sale order No-:<b> %s </b> product_no-:'%s ' (%s) Qty are Purchased on Date :<b>%s \n</b> and Move to Quality Checking
						    </p>
						    </div>"""%(po_ids.request_id.n_sale_order_line.order_id.name or '',po_ids.request_id.n_sale_order_line.product_id.name+po_ids.request_id.n_sale_order_line.product_id.default_code or '',str(n_qty),str(date.today()))

									body_html = self.pool['mail.template'].render_template(self._cr, self._uid, body_html, 'sale.order.line',po_ids.request_id.n_sale_order_line.id, context=self._context)
				
									temp_id.write({'body_html': body_html, 'email_to':recipient_partners,'email_from': user_obj.partner_id.email})
									temp_id.send_mail(po_ids.request_id.n_sale_order_line.id)
	#  Pre-Stock Operation start >>>>>>>>>>>>
		if rec.picking_type_id.code=='internal' and rec.picking_type_id.default_location_src_id.pre_ck == True :
			po_ids=self.env['purchase.order'].search([('name','=',rec.origin)])
			message=''
			if not po_ids:
			   for n_line in rec.pack_operation_product_ids:
				n_qty=p_qty= n_line.qty_done if n_line.qty_done else n_line.product_qty
				message += '<h4 style="color:green">Qty move to '+str(rec.location_dest_id.name)+'</h4> <li>Product: '+str(n_line.product_id.name)+'</li><li>Quantity :'+str(n_qty)+str(n_line.product_uom_id.name)+'</li>'
				if n_line.n_sale_order_line:
					n_status_rel=[]
					reserve_qty =extra_qty=0.0
					for line in self.env['reserve.history'].search([('sale_line','=',n_line.n_sale_order_line.id)]):
						if line.n_status in ('release','cancel','delivered'):
							reserve_qty -= float(line.res_qty)
						if line.n_status in ('reserve'):
							reserve_qty += float(line.res_qty)
					if n_line.n_sale_order_line.product_uom_qty < (reserve_qty + n_qty):
						extra_qty = (reserve_qty + n_qty) - n_line.n_sale_order_line.product_uom_qty
						n_qty = n_line.n_sale_order_line.product_uom_qty - reserve_qty
					if n_qty > 0.0:
						vals={'product_id':n_line.product_id.id,'res_qty':n_qty,
							'sale_line':n_line.n_sale_order_line.id,
							'n_status':'reserve','n_reserve_Type':'mo','res_date':date.today(),}
						ids=self.env['reserve.history'].create(vals)
					search_id=self.env['sale.order.line.status'].search([('n_string','=','warehouse')],limit=1) 
					if search_id:
						n_status_rel.append((4,search_id.id))
					new_id=self.env['sale.order.line.status'].search([('n_string','=','pre_stock')],limit=1) 
					if new_id:
						n_status_rel.append((3,new_id.id))
					
					n_line.n_sale_order_line.write({'reserved_qty':(reserve_qty+n_qty),
									'n_extra_qty':extra_qty,'n_status_rel':n_status_rel})
					n_line.n_sale_order_line.product_id.n_reserve_qty +=p_qty
			else:
			   for n_line in rec.pack_operation_product_ids:
				n_qty=p_qty= n_line.qty_done if n_line.qty_done else n_line.product_qty
				message += '<h4 style="color:green">Qty move to '+str(rec.location_dest_id.name)+'</h4> <li>Product: '+str(n_line.product_id.name)+'</li><li>Quantity :'+str(n_qty)+' '+str(n_line.product_uom_id.name)+'</li>'
				if po_ids.request_id.n_sale_order_line and not po_ids.production_ids:
					n_status_rel=[]
					reserve_qty =extra_qty=0.0
					for line in self.env['reserve.history'].search([('sale_line','=',po_ids.request_id.n_sale_order_line.id)]):
						if line.n_status in ('release','cancel','delivered'):
							reserve_qty -= float(line.res_qty)
						if line.n_status in ('reserve'):
							reserve_qty += float(line.res_qty)
			
					if po_ids.request_id.n_sale_order_line.product_uom_qty < (reserve_qty + n_qty):
						extra_qty = (reserve_qty + n_qty) - po_ids.request_id.n_sale_order_line.product_uom_qty
						n_qty = po_ids.request_id.n_sale_order_line.product_uom_qty - reserve_qty
					if n_qty > 0.0:
						vals={'product_id':po_ids.request_id.n_sale_order_line.product_id.id,'res_qty':n_qty,
							'sale_line':po_ids.request_id.n_sale_order_line.id,
							'n_status':'reserve','n_reserve_Type':'po','res_date':date.today(),}
						ids=self.env['reserve.history'].create(vals)
					search_id=self.env['sale.order.line.status'].search([('n_string','=','warehouse')],limit=1) 
					if search_id:
						n_status_rel.append((4,search_id.id))
					new_id=self.env['sale.order.line.status'].search([('n_string','=','pre_stock')],limit=1) 
					if new_id:
						n_status_rel.append((3,new_id.id))
					
					po_ids.request_id.n_sale_order_line.write({'reserved_qty':(reserve_qty+n_qty),
									'n_extra_qty':extra_qty,'n_status_rel':n_status_rel})
					po_ids.request_id.n_sale_order_line.product_id.n_reserve_qty +=p_qty
			if message:
				rec.message_post(message)
	# Pre-Stock opeartion end <<<<<<<<<<<<<<
	#QC opeartion start>>>>		
		if rec.picking_type_id.code=='internal' and rec.picking_type_id.n_quality_ck == True:
			for n_line in rec.pack_operation_product_ids:
				n_status_rel=[]
				print "...................////",n_line.n_sale_order_line,n_line
				if n_line.n_sale_order_line:
					search_id=self.env['sale.order.line.status'].search([('n_string','=','pre_stock')],limit=1) 
					if search_id:
						n_status_rel.append((4,search_id.id))
				
					new_id=self.env['sale.order.line.status'].search([('n_string','=','quality_check')],limit=1) 
					if new_id:
						n_status_rel.append((3,new_id.id))
					n_line.n_sale_order_line.write({'n_status_rel':n_status_rel})
	#QC opeartion END<<<<<<<<<<		
		super(stock_picking,self).do_transfer()
	#CH_N080 >>>>>>>>>>>> add code to set state 
		#if rec.picking_type_id.code=='internal' and rec.picking_type_id.n_quality_ck == True:
		#	rec.state= 'done'
		if rec.picking_type_id.code=='incoming' and not self._context.get('do_only_split'):
			#CH_N069 add code for >>>
			po_ids=self.env['purchase.order'].search([('name','=',rec.origin)])
			if po_ids:
				rec.state= 'done'
	#CH_N080 <<<<<<<<<<<< add code to set state 
		if rec.picking_type_id.code=='outgoing' and not self._context.get('do_only_split'):
			rec.do_unreserve()
			for move in rec.move_lines:
				move.state='transit'
			#rec.state= 'transit'
			delivery_ids=[]
			
			for line in rec.pack_operation_product_ids:
				#qry="UPDATE stock_quant SET qty =qty+"+str(line.qty_done)+" where location_id = "+str(line.location_id.id)+" and product_id="+str(line.product_id.id)
				#self.env.cr.execute(qry)
			
				#CH_N061 code to update status in sale order line >>>
				qty=0.0
                                n_status_list=[]
		    		if line.qty_done > 0:
	         			qty = line.qty_done
		    		else:
		        		qty = line.product_qty
				
				if line.n_sale_order_line:
				    #CH_N062 >>>
					delivery_ids.append(line.n_sale_order_line.id)
					vals={'product_id':line.product_id.id,'res_qty':qty,'n_status':'r_t_dispatch',
					      'res_date':datetime.now(),'sale_line':line.n_sale_order_line.id,'picking_id':rec.id}
					if qty>0.0:
						self.env['reserve.history'].create(vals)
				   #CH_N062<<<<
					#CH_N074>>>>
					n_type='partial'
					qty=0.0
					for n_line in line.n_sale_order_line.res_ids:
						if n_line.n_status in ('delivered','r_t_dispatch'):
							qty += n_line.res_qty 
					if line.n_sale_order_line.product_uom_qty <= qty:
						n_type='full'
					date_rec = self.env['mrp.delivery.date'].search([('n_picking_id','=',line.picking_id.id),
										('n_line_id1','=',line.n_sale_order_line.id)], limit=1)
                                        print"YUUUUUuuuuuuuu",date_rec
					if not date_rec :
						self.env['mrp.delivery.date'].create(
									{'n_dispatch_date_d':line.picking_id.min_date,
									'n_status':'r_t_dispatch',
									'n_picking_id':line.picking_id.id,'n_type':n_type,
									'n_line_id1':line.n_sale_order_line.id})
					else:
						self.env['schedule.delivery.date.history'].create({
									'n_nextdate':date.today(),
									'n_status':'validate',
									'n_picking_id':line.picking_id.id,
									'n_line_id':line.n_sale_order_line.id,
									'delivery_id':date_rec[0].id})
						date_rec.n_status='r_t_dispatch'
						date_rec.n_type=n_type
						date_rec.n_dispatch_date_d=date.today()
					
					#line.n_sale_order_line.n_schdule_date=line.picking_id.min_date
					line.n_sale_order_line._get_schedule_date()
				    #CH_N074<<<<
					search_id=self.env['sale.order.line.status'].search([('n_string','=','r_t_dispatch')],limit=1) #Add
					if search_id:
						n_status_list.append((4,search_id.id))
					if n_type=='full':
						new_id=self.env['sale.order.line.status'].search([('n_string','=','warehouse')],limit=1) # remove
						if new_id:
						   n_status_list.append((3,new_id.id))
                                if line.n_sale_order_line:
				   line.n_sale_order_line.n_status_rel=n_status_list
				#CH_N061<<<<
			delivery_rec = self.env['mrp.delivery.date'].search([('n_picking_id','=',line.picking_id.id),
										('n_line_id1','not in',delivery_ids)])
			if delivery_rec:
				date_ids=self.env['schedule.delivery.date.history'].search([
								('delivery_id','in',[ d.id for d in delivery_rec])])
				if date_ids:
					date_ids.unlink()
				delivery_rec.unlink()
	return True
	
    @api.multi
    def schedule_date_change(self):
	order_form = self.env.ref('stock_merge_picking.schedule_delivery_date_change_form_view', False)
	context = self._context.copy()
	context.update({'default_n_prevoiusdate':self.min_date,
			'default_n_prevoiusdate1':self.min_date,'default_n_status':'scheduled',
			'default_n_picking_id':self.id})
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'schedule.delivery.date.history',
            'views': [(order_form.id, 'form')],
            'view_id': order_form.id,
            'target': 'new',
	    'context':context,}

    @api.multi
    def dispatch_date_change(self):
	order_form = self.env.ref('stock_merge_picking.dispatch_date_change_form_view', False)
	context = self._context.copy()
	context.update({'default_n_prevoiusdate':self.dispatch_date,
			'default_n_prevoiusdate1':self.dispatch_date,'default_n_status':'schedule_dispatch',
			'default_n_picking_id':self.id})
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'schedule.delivery.date.history',
            'views': [(order_form.id, 'form')],
            'view_id': order_form.id,
            'target': 'new',
	    'context':context,}

#CH_N067 add fields to to get proper location >>>
class stockPickingType(models.Model):
	_inherit = "stock.picking.type"

	n_quality_ck = fields.Boolean("Quality Location", default=False)
	n_scrap_ck	= fields.Boolean("Scrap Location", default=False)

	@api.multi
	def write(self,vals):
		if vals.get('code')== False:
			return True
		return super(stockPickingType,self).write(vals)

from openerp.osv import fields, osv
class stockPickingTypen(osv.osv):
	_inherit = "stock.picking.type"
	
	def _get_picking_count1(self, cr, uid, ids, field_names, arg, context=None):
		obj = self.pool.get('stock.picking')
		domains = {
		   # 'count_picking_draft': [('state', '=', 'draft')],
		   # 'count_picking_waiting': [('state', 'in', ('confirmed', 'waiting'))],
		    'count_picking_ready': [('state', '=','transit')],
		   # 'count_picking': [('state', 'in', ('assigned', 'waiting', 'confirmed', 'partially_available'))],
		  #  'count_picking_late': [('min_date', '<', time.strftime(DEFAULT_SERVER_DATETIME_FORMAT)), ('state', 'in', ('assigned', 'waiting', 'confirmed', 'partially_available'))],
		  #  'count_picking_backorders': [('backorder_id', '!=', False), ('state', 'in', ('confirmed', 'assigned', 'waiting', 'partially_available'))],
		}
		result = {}
		for field in domains:
		    data = obj.read_group(cr, uid, domains[field] +
		        [('state', 'not in', ('done', 'cancel')), ('picking_type_id', 'in', ids)],
		        ['picking_type_id'], ['picking_type_id'], context=context)
		    count = dict(map(lambda x: (x['picking_type_id'] and x['picking_type_id'][0], x['picking_type_id_count']), data))
		    for tid in ids:
		        result.setdefault(tid, {})[field] = count.get(tid, 0)
		#for tid in ids:
		#    if result[tid]['count_picking']:
		#        result[tid]['rate_picking_late'] = result[tid]['count_picking_late'] * 100 / result[tid]['count_picking']
		#        result[tid]['rate_picking_backorders'] = result[tid]['count_picking_backorders'] * 100 / result[tid]['count_picking']
		#    else:
		#        result[tid]['rate_picking_late'] = 0
		#        result[tid]['rate_picking_backorders'] = 0
		return result
		
	_columns = {	
		'count_picking_ready': fields.function(_get_picking_count1,
            			type='integer', multi='_get_picking_count1'),}
#CH_N067 <<<

