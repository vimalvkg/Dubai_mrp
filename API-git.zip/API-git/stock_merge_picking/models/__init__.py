# -*- coding: utf-8 -*-
import stock
import sale_fast_cancel
import stock_move
import mrp
import sale_instruction
import account_receipt_parser
import res_partner
import sale
import stock_stock
