# -*- encoding: utf-8 -*-


from openerp.osv import osv, fields
from openerp.tools.translate import _

#class SalesSupportSearchWizard(models.TransientModel):
#    _name = 'sale.support.search.wizard'


